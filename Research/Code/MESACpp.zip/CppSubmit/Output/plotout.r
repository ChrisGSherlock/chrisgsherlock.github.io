## Plots output from the file.
## Set up for LV model which has 3 parameters. Log pitilde is also plotted.
## Change file names to suit the output from the runs you do.

fname="MESALV20L1500G10MW20.txt"
##fname="nMESALV20L1400G10MW1.txt"
##fname="ghsLV20L160G0a980.txt"

a=read.table(file=fname)
par(mfrow=c(2,2))

for (i in 1:4) {
    plot(a[,i],type="l")
}
