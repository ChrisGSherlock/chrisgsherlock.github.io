#include <iostream>
#include <armadillo>
#include "MJPsystems.h"
#include <chrono>

using namespace std;

// Insertion Sort of a std double vec
void InsSort(std::vector<double> &pvec) {
  int j=1,k;
  double kx;
  while (j<(int)pvec.size()) {
    kx=pvec[j];
    k=j-1;
    while ((k>=0) && (pvec[k]>kx)) {
      pvec[k+1]=pvec[k];
      k--;
    }
    pvec[k+1]=kx;
    j++;
  }
}

// Convert between species number vector and a linear index

int LoHi_xtoj(arma::vec xs, arma::mat LoHi) {
  int i=0, j, wprev=1, nx=LoHi.n_cols;

  for (j=0;j<nx;j++) {
    i=i+wprev*(xs(j)-LoHi(0,j));
    wprev=wprev*(LoHi(1,j)-LoHi(0,j)+1);
  }
  return i;
}

arma::Col<double> LoHi_jtox(int i, arma::mat LoHi) {
  int j, wnext=1, nx=LoHi.n_cols;
  arma::Col<double> xs(nx);

  for (j=0;j<nx;j++) {
    wnext=LoHi(1,j)-LoHi(0,j)+1;
    xs(j)=LoHi(0,j)+i%wnext;
    i=i/wnext;
  }
  return xs;
}

int LoHi_x_in_range(arma::vec xs, arma::mat LoHi) {
  arma::uvec ir1=(xs.t() >= LoHi.row(0)).t();
  arma::uvec ir2=(xs.t() <= LoHi.row(1)).t();
  return (int) (prod(ir1)*prod(ir2));
}

// mw is minimum value of Hi-Lo; prevents impossible transition in R_1
// absmax is {-1,-1,...} if there is no upper bound
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, double gamma, int mw, arma::vec absmin, arma::vec absmax) {
  double dmw=(double) mw -0.5;
  int i,j;
  int ns=xs1.n_elem;
  arma::mat LoHi(2,ns);
  
  for (j=0;j<ns;j++) {
    if (xs1(j)>xs2(j)) {
      LoHi(1,j)=xs1(j); LoHi(0,j)=xs2(j);
    }
    else {
      LoHi(1,j)=xs2(j); LoHi(0,j)=xs1(j);
    }
    while (LoHi(1,j)-LoHi(0,j)<dmw) {// if too tight then stretch 
      LoHi(0,j)=max(absmin(j),LoHi(0,j)-1.0); 
      LoHi(1,j)=LoHi(1,j)+1.0;
      if (absmax(j)>absmin(j) && (LoHi(1,j)>absmax(j))) {
	LoHi(1,j)=absmax(j);
      }
    }
  }

  for (i=2;i<=region;i++) {
    for (j=0;j<ns;j++) {
      double step=max(1.0,(double)(int)(gamma*(LoHi(1,j)-LoHi(0,j))));
      LoHi(1,j)=LoHi(1,j)+step;
      LoHi(0,j)=max(LoHi(0,j)-step,absmin(j));
      if ((absmax(j)>=absmin(j)) && (LoHi(1,j)>absmax(j))) {
	LoHi(1,j)=absmax(j);
      }
    }
  }

  return LoHi;
}
// Default is a minimum of 0 and max of infinity
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, double gamma, int mw=1) {
  double dmw=(double) mw -0.5;
  int i,j;
  int ns=xs1.n_elem;
  arma::mat LoHi(2,ns);
  
  for (j=0;j<ns;j++) {
    if (xs1(j)>xs2(j)) {
      LoHi(1,j)=xs1(j); LoHi(0,j)=xs2(j);
    }
    else {
      LoHi(1,j)=xs2(j); LoHi(0,j)=xs1(j);
    }
  }
  while (LoHi(1,j)-LoHi(0,j)<dmw) {// if too tight then stretch 
    LoHi(0,j)=max(0.0,LoHi(0,j)-1.0); 
    LoHi(1,j)=LoHi(1,j)+1.0;
  }

  for (i=2;i<=region;i++) {
    for (j=0;j<ns;j++) {
      double step=max(1.0,(double)(int)(gamma*(LoHi(1,j)-LoHi(0,j))));
      LoHi(1,j)=LoHi(1,j)+step;
      LoHi(0,j)=max(LoHi(0,j)-step,0.0);
    }
  }

  return LoHi;
}


// Vector of gammas - not used
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, arma::vec gammas, int mw, arma::vec absmin, arma::vec absmax) {
  double dmw=(double) mw -0.5;
  int i,j;
  int ns=xs1.n_elem;
  arma::mat LoHi(2,ns);
  
  for (j=0;j<ns;j++) {
    if (xs1(j)>xs2(j)) {
      LoHi(1,j)=xs1(j); LoHi(0,j)=xs2(j);
    }
    else {
      LoHi(1,j)=xs2(j); LoHi(0,j)=xs1(j);
    }
    while (LoHi(1,j)-LoHi(0,j)<dmw) {// if too tight then stretch 
      LoHi(0,j)=max(absmin(j),LoHi(0,j)-1.0); 
      LoHi(1,j)=LoHi(1,j)+1.0;
      if (absmax(j)>absmin(j)) {
	LoHi(1,j)=min(LoHi(1,j),absmax(j));
      }
    }
  }

  for (i=2;i<=region;i++) {
    for (j=0;j<ns;j++) {
      double step=max(1.0,(double)(int)(gammas(j)*(LoHi(1,j)-LoHi(0,j))));
      LoHi(1,j)=LoHi(1,j)+step;
      LoHi(0,j)=max(LoHi(0,j)-step,absmin(j));
      if ((absmax(j)>=absmin(j)) && (LoHi(1,j)>absmax(j))) {
	LoHi(1,j)=absmax(j);
      }
    }
  }

  return LoHi;
}
// Default is a minimum of 0 and max of infinity (vector of gammas)
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, arma::vec gammas, int mw=1) {
  double dmw=(double) mw -0.5;
  int i,j;
  int ns=xs1.n_elem;
  arma::mat LoHi(2,ns);
  
  for (j=0;j<ns;j++) {
    if (xs1(j)>xs2(j)) {
      LoHi(1,j)=xs1(j); LoHi(0,j)=xs2(j);
    }
    else {
      LoHi(1,j)=xs2(j); LoHi(0,j)=xs1(j);
    }
  }
  while (LoHi(1,j)-LoHi(0,j)<dmw) {// if too tight then stretch 
    LoHi(0,j)=max(0.0,LoHi(0,j)-1.0); 
    LoHi(1,j)=LoHi(1,j)+1.0;
  }

  for (i=2;i<=region;i++) {
    for (j=0;j<ns;j++) {
      double step=max(1.0,(double)(int)(gammas(j)*(LoHi(1,j)-LoHi(0,j))));
      LoHi(1,j)=LoHi(1,j)+step;
      LoHi(0,j)=max(LoHi(0,j)-step,0.0);
    }
  }

  return LoHi;
}
// Default default is region 1
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2) {
  int j;
  int ns=xs1.n_elem;
  arma::mat LoHi(2,ns);
  
  for (j=0;j<ns;j++) {
    if (xs1(j)>xs2(j)) {
      LoHi(1,j)=xs1(j); LoHi(0,j)=xs2(j);
    }
    else {
      LoHi(1,j)=xs2(j); LoHi(0,j)=xs1(j);
    }
  }
  if (LoHi(1,j)-LoHi(0,j)<0.5) {// if too tight then stretch 
    LoHi(0,j)=max(0.0,LoHi(0,j)-1.0); 
    LoHi(1,j)=LoHi(1,j)+1.0;
  }

  return LoHi;
}



// xs1 and xs2 are d-vectors of the exact state at the start and end.
// The region with r=(0,0,..,0) (a d-vector)
//    is the smallest box containing these two vectors
// r[i] =2 means add 2 extra states to either end for cpt 2
//  subject to the absolute bounds
// LoHi has two rows: Lo is the vec of lower bounds and Hi is upper bounds
/*
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, arma::vec rs, arma::vec absmin, arma::vec absmax) {
  int i,nx = xs1.n_rows;
  arma::mat LoHi(2,nx);

  for (i=0;i<nx;i++) {
    LoHi(0,i)=max(absmin(i), min(xs1(i),xs2(i))-rs(i));
    if (absmax(i)<absmin(i)) { // no upper bound
      LoHi(1,i)=max(xs1(i),xs2(i))+rs(i);
    }
    else {
      LoHi(1,i)=min(absmax(i), max(xs1(i),xs2(i))+rs(i));
    }
  }

  return LoHi;
}
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, arma::vec rs) {
  int i,nx = xs1.n_rows;
  arma::mat LoHi(2,nx);

  for (i=0;i<nx;i++) {
    LoHi(0,i)=min(xs1(i),xs2(i))-rs(i);
    LoHi(1,i)=max(xs1(i),xs2(i))+rs(i);
  }

  return LoHi;
}
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2) {
  int i,nx = xs1.n_rows;
  arma::mat LoHi(2,nx);

  for (i=0;i<nx;i++) {
    LoHi(0,i)=min(xs1(i),xs2(i));
    LoHi(1,i)=max(xs1(i),xs2(i));
  }

  return LoHi;
}
*/


// Insertion Sort and Rearrange.
// Each row of prowbycol (nrow by nr) in increasing order
// Rearranges pratbycol accordingly
// For row[i], only sorts the first pnrowbycol[i] elements 
void InsSortR(int nrow, int nr, int *prowbycol, double *pratbycol, int *pnrowbycol) {

  int i,j,k,kx;
  double xrat;
  
  for (i=0;i<nrow;i++) {
    int ntosort=pnrowbycol[i];
    j=1;
    while (j<ntosort) {
      xrat=pratbycol[i*nr+j];
      kx=prowbycol[i*nr+j];
      k=j-1;
      while ((k>=0) && (prowbycol[i*nr+k]>kx)) {
	prowbycol[i*nr+k+1]=prowbycol[i*nr+k];
	pratbycol[i*nr+k+1]=pratbycol[i*nr+k];
	k--;
      }
      pratbycol[i*nr+k+1]=xrat;
      prowbycol[i*nr+k+1]=kx;
      j++;
    }
  }
}

// Use the lists of indices and values to create the sparse matrix
// Siz = size of statespace excluding possible coffin
arma::sp_mat create_Q_by_batch(int siz, int nr, int nentries, int *pQn, int *pQind, double *pQrat, double *pQdiag, double *pQcoff=NULL) {

  int i,j, currind=0;
  arma::sp_mat Q;
  arma::umat locations=arma::umat(2,nentries);
  arma::Col<double> values=arma::Col<double>(nentries);;

  for (i=0;i<siz;i++) {
    int nind=pQn[i];
    j=0;
    while ((pQind[i*nr+j]<i) && (j<nind)) {
      locations(0,currind)=pQind[i*nr+j];
      locations(1,currind)=i;
      values(currind)=pQrat[i*nr+j];
      j++; currind++;
    }
    locations(0,currind)=i;
    locations(1,currind)=i;
    values(currind)=pQdiag[i];
    currind++;
    while (j<nind) {
      locations(0,currind)=pQind[i*nr+j];
      locations(1,currind)=i;
      values(currind)=pQrat[i*nr+j];
      j++; currind++;
    }
  }
  // finally do the coffin column
  if (pQcoff!=NULL) {
    for (i=0;i<siz;i++) {
      locations(0,currind)=i;
      locations(1,currind)=siz;
      values(currind++)=pQcoff[i];
    }
  }

  //  cout << "siz=" << siz << " nentries=" << nentries <<"\n";
  if (pQcoff == NULL) {
    Q=arma::sp_mat(locations,values,siz+0,siz+0,false,true);    
  }
  else {
    Q=arma::sp_mat(locations,values,siz+1,siz+1,false,true);
  }
  return Q;
}

int LoHi_size(arma::mat LoHi) {
  const int nc = (int) LoHi.n_cols;
  int siz=1, i;
  for (i=0;i<nc;i++) {
    siz=siz*(LoHi(1,i)-LoHi(0,i)+1);
  }
  return siz;
}
// By column and using the batch constructor.
arma::sp_mat LoHi_create_Q(arma::mat LoHi, arma::vec thetas,
			    const arma::mat S,
			    double (*pRates)(int, arma::vec, arma::vec)) {
  const int nr=S.n_cols, siz=LoHi_size(LoHi);
  double *pQrat, *pQcoff, *pQdiag;
  int *pQind, *pQn;
  int i, j, inew, ncoff=0;
  int nentries=0; // total # non-zero entries in the sparse matrix
  arma::sp_mat Q;

  pQrat=new double[siz*nr]; pQdiag=new double[siz]; pQcoff=new double[siz]; 
  pQind= new int[siz*nr];  pQn = new int[siz];
  
  fill(pQn,pQn+siz,0);

  // Get all rates and store according to [column,order seen]
  
  for (i=0;i<siz;i++) {
    arma::vec xs=LoHi_jtox(i,LoHi);
    double sumi=0.0, sumcoffin=0.0;
    for (j=0;j<nr;j++) {
      arma::vec del=S.col(j);
      double rat=(*pRates)(j,xs,thetas);
      if (rat>0) {
	if (LoHi_x_in_range(xs+del,LoHi)) {
	  inew=LoHi_xtoj(xs+del,LoHi); 
	  pQrat[inew*nr+pQn[inew]]=rat;
	  pQind[inew*nr+pQn[inew]]=i;
	  pQn[inew]=pQn[inew]+1;
	  nentries++;
	}
	else { // coffin
	  sumcoffin+=rat;
	  ncoff++;
	}
	sumi+=rat;
      }
    }
    pQdiag[i]=-sumi;
    pQcoff[i]=sumcoffin; // some of these are zero but sp_mat realises
  }

  // Sort the rows within a column using insertion sort
  InsSortR(siz, nr, pQind, pQrat, pQn);

  if (ncoff>0) {
    nentries=nentries+2*siz; //coffin+diags (efficient as sp_mat recognises 0s)
    Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,pQcoff);
  }
  else {
    nentries=nentries+siz; //just diagonals
    Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,NULL);
  }
  
  delete[] pQrat; delete[] pQind; delete[] pQn;
  delete[] pQdiag; delete[] pQcoff;
  
  return Q;
}

int SIR_x_in_range(arma::vec xs, int npop) {
  return (int) ((xs[0]+xs[1]<=npop)*(xs[0]>=0)*(xs[1]>=0));
}
int SEIR_x_in_range(arma::vec xs, int npop) {
  return (int) ((xs[0]+xs[1]+xs[2]<=npop)*(xs[0]>=0)*(xs[1]>=0)*(xs[2]>=0));
}
int SIR_size(int npop) {
  return (npop+1)*(npop+2)/2;
}
int SEIR_size(int npop) {
  return (npop+1)*(npop+2)*(npop+3)/6;
}


int SIR_xtoj(arma::vec xs, int npop) {
  int j;
  if (!SIR_x_in_range(xs,npop)) {
    j=-1;
  }
  else {
    int S=(int)xs[0], I=(int)xs[1];
    int nms=npop-S, nmsi=nms-I;
    j=SIR_size(npop)-1-(nms)*(nms+1)/2-nmsi;
  }
  return j; 
}
int SEIR_xtoj(arma::vec xs, int n) {
  int j;
  if (!SEIR_x_in_range(xs,n)) {
    j=-1;
  }
  else {
    int S=(int)xs[0], E=(int)xs[1], I=(int)xs[2];
    int nms=n-S, nmse=nms-E, nmsei=nmse-I;
    j=SEIR_size(n)-1-nms*(nms+1)*(nms+2)/6-nmse*(nmse+1)/2-nmsei;
  }
  return j; 
}

arma::Col<double> SIR_jtox(int j, int npop) {
  int ai=(npop+1)*(npop+2)-2*(j+1);
  double ad=(double) ai;
  int nminusS=(int) (sqrt(1+4*ad)/2-0.5);
  int S=npop-nminusS;
  int I=j-SIR_size(npop)+SIR_size(npop-S);
  arma::Col<double> xs={(double)S,(double)I};

  return xs;
}


arma::Col<double> SEIR_jtox(int j, int npop) {
  int ai=(npop+1)*(npop+2)*(npop+3)-6*(j+1);
  int bi=(npop+1)*(npop+2)*(npop+3)+8-6*(j+1);
  double adcr=exp(log((double) ai)/3.0); // cube root
  double bdcr=exp(log((double) bi)/3.0); // cube root
  int lb=npop-(int) adcr;
  int ub=npop+2-(int) bdcr;
  int s=lb;
  arma::Col<double> xs;
  int checkind=-1;

  if (lb<0) {
    s=0;
  }

  // For each possible S, get remaining j and hence E and I
  // - and see if these give the right index.
  while ((s<=ub) && (checkind!=j)) {
    int rem = j-SEIR_size(npop)+SEIR_size(npop-s);
    arma::vec EI=SIR_jtox(rem, npop-s); // is correct if rem is.
    xs={(double)s,EI(0),EI(1)};
    checkind=SEIR_xtoj(xs,npop);
    s++;
  }
  if (checkind != j) {
    cout << "Error in code: " <<"j="<<j<<" checkind="<<checkind<< xs<<"\n";
  }
  
  return xs;
}

// Ho, Crawford and Suchard birth formulation of state space
arma::mat SIRbirth_get_LoHi(arma::vec x0, arma::vec x1) {
  arma::vec ys0=arma::zeros(2), ys1(2);
  double nbirthI, nbirthR;
  
  // Convert from (S,I) to range for number of births

  nbirthI=x0(0)-x1(0); // # I births is S0-S1
  nbirthR=nbirthI+x0(1)-x1(1); // # R births = R_1=R0= S_0+I_0-S_1-I_1
  ys1(0)=nbirthI; ys1(1)=nbirthR;
  
  return get_LoHi(ys0, ys1);
}

int SIRbirth_x_in_range(arma::vec xs, arma::vec x0, arma::mat LoHi) {
  arma::vec ys=arma::vec(2);
  double nbirthI, nbirthR;

  nbirthI=x0(0)-xs(0);
  nbirthR=nbirthI+x0(1)-xs(1);
  ys(0)=nbirthI; ys(1)=nbirthR;

  return LoHi_x_in_range(ys,LoHi);
}
int SIRbirth_xtoj(arma::vec xs, arma::vec x0, arma::mat LoHi) {
  arma::vec ys=arma::vec(2);
  double nbirthI, nbirthR;

  nbirthI=x0(0)-xs(0);
  nbirthR=nbirthI+x0(1)-xs(1);
  ys(0)=nbirthI; ys(1)=nbirthR;

  return LoHi_xtoj(ys,LoHi);
}
arma::vec SIRbirth_jtox(int j, arma::vec x0, arma::mat LoHi) {
  arma::vec ys=LoHi_jtox(j,LoHi);
  double nbirthI=ys(0), nbirthR=ys(1);
  arma::vec xs=arma::vec(2);
  xs(0)=x0(0)-nbirthI; xs(1)=x0(1)+nbirthI-nbirthR;

  return xs;
}

arma::sp_mat SIR_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
			      double (*pRates)(int, arma::vec, arma::vec)) {
  int nr=S.n_cols;
  double *pQrat, *pQcoff, *pQdiag;
  int *pQind, *pQn;
  int siz=SIR_size(npop), i, j, inew;
  int nentries=0; // total # non-zero entries in the sparse matrix
  arma::sp_mat Q;

  pQrat=new double[siz*nr]; pQdiag=new double[siz]; pQcoff=new double[siz]; 
  pQind= new int[siz*nr];  pQn = new int[siz];
  
  fill(pQn,pQn+siz,0);

  for (i=0;i<siz;i++) {
    arma::vec xs=SIR_jtox(i,npop);
    double sumi=0.0;
    
    for (j=0;j<nr;j++) {
      arma::vec del=S.col(j);
      double rat=(*pRates)(j,xs,thetas);
      if (rat>0) {
	if (SIR_x_in_range(xs+del,npop)) {
	  inew=SIR_xtoj(xs+del,npop);
	  pQrat[inew*nr+pQn[inew]]=rat;
	  pQind[inew*nr+pQn[inew]]=i;
	  pQn[inew]=pQn[inew]+1;
	  nentries++;
	}
	else { // worry
	  cout << "Error: SIR MJP can leave bounds\n";
	}
	sumi+=rat;
      }
    }
    pQdiag[i]=-sumi;
  }
  nentries=nentries+siz; //allow for diagonals but not coffin

  InsSortR(siz, nr, pQind, pQrat, pQn);
  Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,NULL);

  delete[] pQrat; delete[] pQind; delete[] pQn;
  delete[] pQdiag; delete[] pQcoff;
  
  return Q;
}


arma::sp_mat SEIR_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
			       double (*pRates)(int, arma::vec, arma::vec)) {
  int nr=S.n_cols;
  double *pQrat, *pQcoff, *pQdiag;
  int *pQind, *pQn;
  int siz=SEIR_size(npop), i, j, inew;
  int nentries=0; // total # non-zero entries in the sparse matrix
  arma::sp_mat Q;

  pQrat=new double[siz*nr]; pQdiag=new double[siz]; pQcoff=new double[siz]; 
  pQind= new int[siz*nr];  pQn = new int[siz];
  
  fill(pQn,pQn+siz,0);
  
  for (i=0;i<siz;i++) {
    arma::vec xs=SEIR_jtox(i,npop);
    double sumi=0;

    for (j=0;j<nr;j++) {
      arma::vec del=S.col(j);
      double rat=(*pRates)(j,xs,thetas);
      if (rat>0) {
	if (SEIR_x_in_range(xs+del,npop)) {
	  inew=SEIR_xtoj(xs+del,npop);
	  pQrat[inew*nr+pQn[inew]]=rat;
	  pQind[inew*nr+pQn[inew]]=i;
	  pQn[inew]=pQn[inew]+1;
	  nentries++;
	}
	else { // worry
	  cout << "Error: SEIR MJP can leave bounds\n";
	}
	sumi+=rat;
      }
    }
    pQdiag[i]=-sumi;
  }
  nentries=nentries+siz; //allow for diagonals but not coffin

  InsSortR(siz, nr, pQind, pQrat, pQn);
  Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,NULL);

  delete[] pQrat; delete[] pQind; delete[] pQn;
  delete[] pQdiag; delete[] pQcoff;

  return Q;
}
arma::sp_mat SEIRS_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
				double (*pRates)(int, arma::vec, arma::vec)) {
  return SEIR_create_Qfull(npop, thetas, S, pRates);
}
 

arma::sp_mat SIRbirth_create_Q(arma::vec x0, arma::mat LoHi, arma::vec thetas,
			       const arma::mat S,
			       double (*pRates)(int, arma::vec, arma::vec)) {
  int nr=S.n_cols;
  double *pQrat, *pQcoff, *pQdiag;
  int *pQind, *pQn;
  int siz=LoHi_size(LoHi), i, j, inew, ncoff=0;
  int nentries=0; // total # non-zero entries in the sparse matrix
  arma::sp_mat Q;

  pQrat=new double[siz*nr]; pQdiag=new double[siz]; pQcoff=new double[siz]; 
  pQind= new int[siz*nr];  pQn = new int[siz];
  
  fill(pQn,pQn+siz,0);

  // Get all rates and store according to [column,order seen]
  
  for (i=0;i<siz;i++) {
    arma::vec xs=SIRbirth_jtox(i,x0,LoHi);
    double sumi=0.0, sumcoffin=0.0;
    for (j=0;j<nr;j++) {
      arma::vec del=S.col(j);
      double rat=(*pRates)(j,xs,thetas);
      if (rat>0) {
	if (SIRbirth_x_in_range(xs+del,x0,LoHi)) {
	  inew=SIRbirth_xtoj(xs+del,x0,LoHi); 
	  pQrat[inew*nr+pQn[inew]]=rat;
	  pQind[inew*nr+pQn[inew]]=i;
	  pQn[inew]=pQn[inew]+1;
	  nentries++;
	}
	else { // coffin
	  sumcoffin+=rat;
	  ncoff++;
	}
	sumi+=rat;
      }
    }
    pQdiag[i]=-sumi;
    pQcoff[i]=sumcoffin; // some of these are zero but sp_mat realises
  }

  // Sort the rows within a column using insertion sort
  InsSortR(siz, nr, pQind, pQrat, pQn);

  if (ncoff>0) {
    nentries=nentries+2*siz; //coffin+diags (efficient as sp_mat recognises 0s)
    Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,pQcoff);
  }
  else {
    nentries=nentries+siz; //just diagonals
    Q = create_Q_by_batch(siz, nr, nentries, pQn, pQind, pQrat, pQdiag,NULL);
  }
  
  delete[] pQrat; delete[] pQind; delete[] pQn;
  delete[] pQdiag; delete[] pQcoff;
  
  return Q;
}


/*
int main(int argc, const char** pargv) {
  arma::vec xs;
  arma::vec LVthetas={.3,.4,.01};
  arma::vec SIRthetas={2,5};
  arma::vec SEIRthetas={2,5,10};
  arma::vec Moranthetas={210,20,0.002,0.0,7.0};
  arma::vec Autoregthetas={.1,.7,.35,.2,.1,.9,.3,.1,10};
  arma::sp_mat Q,Q1;
  arma::mat v;
  int i,j;
  int testt=1;

  arma::arma_version ver;
  cout << "ARMA version: "<< ver.as_string() << "\n\n";
  if (argc>1) {
    testt=atoi(pargv[1]); // 0 = individual obs, 1= jump
    cout << "test="<<testt<<"\n";
  }

  if (testt==1) { //  check index<->vector conversions
    arma::mat LoHi={{1,3},{3,6}};
    arma::vec xsbad={-5,6};
    for (i=0;i<12;i++) {
      xs=LoHi_jtox(i,LoHi);
      j=LoHi_xtoj(xs,LoHi);
      cout << i <<" " << j <<"\n" << xs << "\n";
      cout << LoHi_x_in_range(xs,LoHi) << "\n";
    }
    cout << LoHi_x_in_range(xsbad,LoHi) << "\n";
  }

  if (testt==2) { // create small LoHi - truncated LV and full Moran
    arma::mat LoHi={{1,3},{3,4}};
    Q=LoHi_create_Q(LoHi,LVthetas,LV_S,&LV_Rates);
    arma::mat Qdens(Q);
    cout << Qdens << "\n";
    arma::mat LoHi2=arma::colvec({0,Moranthetas(4)});
    Q=LoHi_create_Q(LoHi2,Moranthetas,Moran_S,&Moran_Rates);
    arma::mat Qdens2(Q);
    cout << Qdens2 << "\n";    
  }

  
  if (testt==3) { // SIR conversions
    int i;
    int npop=4;
    int siz=(npop+1)*(npop+2)/2;
    for (i=0;i<siz; i++) {
      arma::Col<double> xs=SIR_jtox(i, npop);
      int j=SIR_xtoj(xs,npop);
      cout << i << " " << j  << "\n" << xs  <<"\n";
    }
  }
  if (testt==4) { // SEIR conversions
    int i;
    int npop=100;
    int siz=(npop+1)*(npop+2)*(npop+3)/6;
    for (i=0;i<siz; i++) {
      arma::Col<double> xsold=SEIR_jtox(i, npop);
      int j=SEIR_xtoj(xsold,npop);
      if (i != j) {
	cout << i << " " << j << "\n";
	cout <<xsold <<"\n";
      }
    }
  }
  if (testt==5) { // create small SIR
    arma::mat LoHi={{0,0},{2,2}};
    Q=SIR_create_Qfull(3,SIRthetas,SIR_S,&SIR_Rates);
    arma::mat Qdens(Q);
    cout << Qdens << "\n";
  }
  if (testt==6) { // small SEIR
    Q=SEIR_create_Qfull(3,SEIRthetas,SEIR_S,&SEIR_Rates);
    arma::mat Qdens(Q);
    cout << Qdens << "\n";
  }


  // Creation (LoHi, SIR, SEIR) - check fast create is valid + timings

  if (testt==7) { 
    arma::vec x0={5,15,10,5};
    arma::vec x1={15,5,15,10};
    arma::vec absmin={0,0,0,0};
    arma::vec absmax={-1,-1,-1,Autoregthetas(8)};
    arma::mat LoHi=get_LoHi(x0,x1,2,1.5,2,absmin,absmax);

    cout << "Autoreg\n";
    auto t1 = std::chrono::high_resolution_clock::now();
    Q=LoHi_create_Q(LoHi,Autoregthetas,Autoreg_S,&Autoreg_Rates);
    auto t2 = std::chrono::high_resolution_clock::now();
    cout<< "Timing: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
    cout << "d="<<Q.n_rows<<", "<< Q.n_nonzero<<" non-zero\n";

    cout << "\nSIR\n";
    t1 = std::chrono::high_resolution_clock::now();
    Q=SIR_create_Qfull(100,SIRthetas,SIR_S,&SIR_Rates);
    t2 = std::chrono::high_resolution_clock::now();
    cout<< "Timing: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
    cout << "d="<<Q.n_rows<<", "<< Q.n_nonzero<<" non-zero\n";

    cout << "\nSEIR\n";
    t1 = std::chrono::high_resolution_clock::now();
    Q=SEIR_create_Qfull(60,SEIRthetas,SEIR_S,&SEIR_Rates);
    t2 = std::chrono::high_resolution_clock::now();
    cout<< "Timing: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
    cout << "d="<<Q.n_rows<<", "<< Q.n_nonzero<<" non-zero\n";
  }

  
  if (testt==8) {  // LV
    arma::vec x0={15,85};
    arma::vec x1={85,15};
    arma::vec absmin={0,0};
    arma::vec absmax={-1,-1};
    arma::mat LoHi=get_LoHi(x0,x1,3,1.5,1,absmin,absmax);

    auto t1 = std::chrono::high_resolution_clock::now();
    Q=LoHi_create_Q(LoHi,LVthetas,LV_S,&LV_Rates);
    auto t2 = std::chrono::high_resolution_clock::now();
    cout<< "Full timing: " << std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
    cout << "d="<<Q.n_rows<<", "<< Q.n_nonzero<<" non-zero\n";
  }

  // Test my sort function
  if (testt==9) {
    int nr=3, nrow=5, i;
    int *piarr=new int[nrow*nr];
    int *pind=new int[nrow];
    double *pdarr=new double[nrow*nr];

    for (i=0;i<nr*nrow;i++) {
      piarr[i]=(nr*nrow-i);
      pdarr[i]=(double)(nr*nrow-i);
      if (i <nrow) {
	pind[i]=nr;
      }      
    }

    for (i=0;i<nr*nrow;i++) {
      cout << pdarr[i] << " " << piarr[i] << "\n";
    }
    InsSortR(nrow,nr,piarr,pdarr,pind);
    for (i=0;i<nr*nrow;i++) {
      cout << pdarr[i] <<  " " << piarr[i] << "\n";
    }
    delete []piarr; delete []pind; delete []pdarr;

  }

  if (testt==10) { // Test HCS birth formulation
    arma::vec x0={100,10};
    arma::vec x1={97,12};
    arma::mat LoHi=SIRbirth_get_LoHi(x0,x1);
    arma::sp_mat Q=SIRbirth_create_Q(x0, LoHi, SIRthetas, SIR_S, &SIR_Rates);

    cout << arma::mat(Q) << "\n";
  }

  
  return 0;

}
*/

