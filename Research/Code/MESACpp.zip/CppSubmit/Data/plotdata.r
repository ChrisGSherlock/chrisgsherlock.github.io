a=read.csv(file="LVmdata.csv")
n=nrow(a)
ts=seq(0,(n-1),1)/2

plot(ts,a[,1],type="p",col="magenta",ylim=c(0,max(a)),xlab="Time",ylab="Count",pch=2,lwd=2)
points(ts,a[,2],col="blue",pch=1,lwd=2)
legend(2,10,legend=c("Pred","Prey"),col=c("magenta","blue"),pch=c(2,1))
dev.print(pdf,file="LVmdata.pdf")
