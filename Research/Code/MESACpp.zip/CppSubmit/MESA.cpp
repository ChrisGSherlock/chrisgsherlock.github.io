#include <iostream>
#include <armadillo>
#include <vector>
#include "MJPsystems.h"
#include "MJPget_Q.h"
#include "matexp.h"
#include <chrono>

// MESA == SINGLE BLOCK update for region - i.e. is a single region

using namespace std;

// If log like for an individual transition is below -700 then
// the transition probability is 0 (as far as the matexp fn is concerned)
// so just record a flat value and let the prior determine behaviour
const double lowest_ll=-700;
// If we used lowest_double then the prior would have no influence due to
// double precision arithmetic, which is silly.

void print_info(int i, int nobs, arma::vec lthetacurr, double lpcurr, double llcurr, double thsumalphas, arma::vec Regions, arma::rowvec llsumalphas, arma::uvec ds, arma::vec rhos) {
  double di=(double)i;
  //  cout << ds.t() <<"\n";
  arma::vec dds=arma::conv_to<arma::vec>::from(ds);

  cout << "\n**Iteration="<<i<<"\n";
  cout << lthetacurr.t();
  //	cout << Regions.t()<<"\n";
  cout << "lp="<<lpcurr<<", ll="<<llcurr<<"\n";
  cout << "Acc rates: theta = " << thsumalphas/di<<", obs ="<<llsumalphas.max()/di<<" \n";
  cout << "Current region: "<<Regions(0)<<"\n";
  //	cout << "eQtrcurr"<<eQtrcurr.t()<<"\n";
  cout << "d (mn, mean, mx)="<<ds.min()<<", "<<arma::accu(dds)/(double)nobs<<", "<<ds.max()<<"\n";
  cout <<"rho (mn, mean, mx)="<<rhos.min()<<", "<<arma::accu(rhos)/(double)nobs<<", "<<rhos.max() << "\n";
  cout << "rhod (mn, mean, mx)=" << arma::min(rhos%dds)<<", "<< arma::accu(rhos%dds)/(double)nobs<<", "<< arma::max(rhos%dds)<<"\n";
  return;
}

int parms_get_check(int argc, const char** pargv, string &rootname, int *pnits,
		    double *plam, double *pgam, int *pmw, int *pprintevery) {
  int bad=0;
  if (argc==1) {
    cout << "USAGE: "<< pargv[0] << " model nits lambda gamma mw printevery\n";
    bad=1;
  }
  int i=1;
  if (argc>i) {
    rootname=pargv[i++];
  }
  if (argc>i) {
    *pnits=atoi(pargv[i++]); 
  }
  if (argc>i) {
    *plam=atof(pargv[i++]); 
  }
  if (argc>i) {
    *pgam=atof(pargv[i++]); 
  }
  if (argc>i) {
    *pmw=atoi(pargv[i++]); 
  }
  if (argc>i) {
    *pprintevery=atoi(pargv[i++]);
  }

  if (*pnits<0) {
    cout << "Bad nits: "<<*pnits<<"\n";
    bad=1;
  }
  if (*plam<0) {
    cout << "Bad lambda: "<< *plam<<"\n";
    bad=1;
  }
  if (*pgam<0) {
    cout << "Bad gamma: "<< *pgam<<"\n";
    bad=1;
  }
  if (*pprintevery<0) {
    cout << "Bad printevery: "<< *pprintevery<<"\n";
  }
  if (!bad) {
    cout << "rootname="<<rootname<< ", nits=" <<*pnits<<", lambda="<<*plam<<", gamma="<<*pgam<<", mw="<<*pmw<<", printevery="<<*pprintevery<<"\n";
  }

  return bad;
}

arma::mat grow_sqV(arma::mat sqV, int db) {
  arma::mat sqVb=arma::zeros(db,db);
  int i,j,d=sqV.n_rows;

  for (i=0;i<d;i++) {
    for (j=0;j<d;j++) {
      sqVb(i,j)=sqV(i,j);
    }
  }
  return sqVb;
}

double log_prior(arma::vec ltheta, arma::vec primns, arma::vec privars) {
  int i;
  double lp=0;
  for (i=0;i<(int)ltheta.n_elem;i++) {
    lp+=-(ltheta(i)-primns(i))*(ltheta(i)-primns(i))/(2*privars(i));
  }
  return lp;
}
void InsertInOutput(arma::vec lthetacurr,double lpost, double mnrg, arma::mat &Output, int iter) {
  int i, n=lthetacurr.n_elem;
  for (i=0;i<n;i++) {
    Output(iter,i)=lthetacurr(i);
  }
  Output(iter,i)=lpost;
  Output(iter,i+1)=mnrg;
}

void get_extreme_obs(arma::mat allobs, arma::vec &xslo, arma::vec &xshi) {
  int i, ns=allobs.n_rows;
  for (i=0;i<ns;i++) {
    arma::mat spec=allobs.row(i);
    xslo(i)=spec.min();
    xshi(i)=spec.max();
  }
}

double eQt_one(arma::vec x0, arma::vec x1, arma::mat LoHi, double deltat,
	       arma::vec lthetacurr, arma::mat S,
	       double (*pRates)(int, arma::vec, arma::vec),
	       double *prho, int *pd) {
  int ss_size=LoHi_size(LoHi); //need one extra for Coffin
  arma::vec nuin=arma::zeros(ss_size+1);
  int ind_start=LoHi_xtoj(x0, LoHi);
  int ind_end=LoHi_xtoj(x1, LoHi);
  nuin(ind_start)=1.0;
  arma::sp_mat Q = deltat*LoHi_create_Q(LoHi, exp(lthetacurr), S, pRates);
  *prho=-Q.min();
  *pd=Q.n_rows;
  arma::rowvec nuout = v_exp_Q(nuin.t(), Q, 1e-15);
  //  cout <<nuout<<"\n";
  //  cout << "trprob="<<nuout(ind_end)<<"\n";
  return nuout(ind_end);
}

arma::vec eQts_all(arma::mat Obs, double Deltat,
		   arma::vec Regions, arma::vec lthetacurr,
		   double gamma, int mw, arma::vec absmin, arma::vec absmax,
		   arma::mat S, double (*pRates)(int, arma::vec, arma::vec)) {
  int j, d;
  int nobs=Obs.n_cols-1;
  std::vector<double> eQts_vec(nobs);
  arma::vec eQts=arma::vec(nobs);
  double rho;

  //  #pragma omp parallel for schedule(dynamic)
  for (j=0;j<nobs;j++) {
    if (Regions(j)>0) {
      arma::mat LoHi=get_LoHi(Obs.col(j),Obs.col(j+1),Regions(j),gamma,mw,absmin,absmax);
      eQts_vec[j]=eQt_one(Obs.col(j),Obs.col(j+1),LoHi,Deltat, lthetacurr, S, pRates,&rho,&d);
    }
    else {
      eQts_vec[j]=0.0;
    }
  }
  for (j=0;j<nobs;j++) {
    eQts(j)=eQts_vec[j];
  }
  return eQts;
}

double ll_from_eQts_block(arma::vec eQtr, arma::vec eQtrm1){
  double ll;
  double b1=0, b2=0;
  
  b1=arma::accu(log(eQtr));
  b2=arma::accu(log(eQtrm1));
  
  if (b2<lowest_ll) {
    ll=b1;
  }
  else {
    ll=b1+log(1-exp(b2-b1));
  }

  return ll;
}

int main(int argc, const char** pargv)  {
  int nits=1, printevery=100;// defaults - change as you call from cmd line
  double gamma=0.1, lam=1.0; // defaults - change as you call from cmd line 
  int mw=0, bad;
  string rootname;
  bad=parms_get_check(argc, pargv, rootname, &nits, &lam, &gamma, &mw, &printevery);
  if (bad) {
    return 0;
  }

  // Use "Identity" for initial run, then create
  //  string sqvname="Identity"; 
  string sqvname="ReadMatrix"; // Read it in
  //**********************************
  double Deltat, nr;
  int mmw;
  arma::dmat S;
  arma::dvec thetainit, primns, privars; 
  double (*pRates)(int, arma::vec, arma::vec);

  if ((rootname=="LV10") || (rootname=="LV20") || (rootname=="LV40")) {
    Deltat=1.0; mmw=1; nr=LV_nr; S=LV_S;
    thetainit={0.3,0.4,0.01}; 
    primns={.2,.2,.02}; // LV prior means
    privars={1.0,1.0,1.0,}; // LV prior variances
    pRates=&LV_Rates;
  }
  else if (rootname=="Sch50") {
    Deltat=4.0; mmw=0; nr=Schlogel_nr; S=Schlogel_S;
    thetainit={3.0,0.5,0.5,3.0}; // Schlogel
    primns={1.0,1.0,1.0,1.0}; // Schlogel
    privars={1.0,1.0,1.0,1.0}; // Sch
    pRates=&Schlogel_Rates;
  }
  else if (rootname=="AR50GWLo") {
    Deltat=1.0; mmw=2; nr=Autoreg_nr; S=Autoreg_S;
    thetainit={0.1,0.7,0.70,0.2,0.1,0.9,0.3,0.1,2.0};//AutoReg
    primns={.2,.2,.2,.2,.2,.2,.2,.2,10.0}; // Autoreg
    privars={1.0,1.0,1.0,1.0,0.1,1.0,1.0,1.0,1.0}; // Autoreg
    pRates=&Autoreg_Rates;
  }
  else {
    cout << "Bad rootname: "<<rootname<<"\n";
    return -1;
  }

 if (rootname=="LV10") {
    Deltat=2.0; 
  }
  else if (rootname=="LV40") {
    Deltat=0.5; 
  }
  const int ns=S.n_rows;
  arma::vec absmin=arma::zeros(ns), absmax=absmin-1; // LV or Autoreg. or Schlog
  if (rootname=="AR50GWLo") {
    absmax(3)=thetainit(8); // Autoreg. has ub on DNA, LV/Sch has no ubs
  }
  if (mw<mmw) {
    cout << "Bad mw: "<< mw<<"\n";
    return -1;
  }
  //*********************************************************************

  primns=log(primns); // prior is on log theta, means were not on log scale
  arma::mat sqV, Obs;
  string obsfname="Data/"+rootname+"data.csv";
  Obs.load(obsfname);
  Obs=Obs.t();
  
  const int  nobs=Obs.n_cols-1;
  if (sqvname != "Identity") {
    sqvname="Data/"+rootname+"sqV.txt";
    sqV.load(sqvname);
  }
  else {
    sqV=arma::mat(arma::diagmat(arma::ones(nr)));// Id - use initially
  }
  if (thetainit.n_elem > sqV.n_rows) {
    sqV=grow_sqV(sqV,thetainit.n_elem);
  }
  const int nz=sqV.n_rows;
  arma::mat Output;
  arma::vec Regions=arma::ones(nobs);
  arma::vec lthetacurr=log(thetainit);
  arma::vec lthetaprop=arma::vec(nz);
  arma::vec eQtrcurr=arma::vec(nobs), eQtrprop=arma::vec(nobs);
  arma::vec eQtrm1curr=arma::zeros(nobs); // region 0 to start with
  arma::vec eQtrm1prop=arma::vec(nobs); 
  double llcurr, llprop, lpcurr, lpprop;
  int i,j;
  double thsumalphas=0; // sum of acc. probs
  arma::rowvec llsumalphas=arma::zeros(1,nobs);
  arma::arma_rng::set_seed_random();
  std::vector<double> rhos_vec(nobs);
  std::vector<int> ds_vec(nobs);
  arma::vec rhos=arma::vec(nobs);
  arma::uvec ds=arma::uvec(nobs);
  
  arma::arma_version ver;
  cout << "ARMA vn: "<< ver.as_string() << "\n\n";
  string outfnameroot="MESA"+rootname+ "L" + to_string((int) (lam*1000))+"G"+to_string((int)(gamma*100))+"MW"+to_string(mw);
  string outfname=outfnameroot+".txt";
  string outmetaname=outfnameroot+".info";
  cout << "Obs="<<obsfname<<", Deltat=" << Deltat <<"\n";
  cout << "sqV="<<sqvname<<"\n"<<sqV<<"\n";

  auto t1 = std::chrono::high_resolution_clock::now();

  Output=arma::zeros(nits+1,nz+2);
  lpcurr=log_prior(lthetacurr,primns,privars);
  eQtrcurr=eQts_all(Obs,Deltat,Regions,lthetacurr,gamma,mw,absmin,absmax,S,pRates);
  llcurr=ll_from_eQts_block(eQtrcurr,eQtrm1curr);
  InsertInOutput(lthetacurr,llcurr+lpcurr,arma::accu(Regions),Output,0);
  //  cout << "eQtrcurr"<<eQtrcurr.t() << "\n";
  //  cout << "Init lp, ll="<<lpcurr<<" "<<llcurr<<"\n";
  
  for (i=0;i<nits;i++) {
    double logr;
    arma::mat delth = lam*sqV*arma::randn(nz);
    arma::vec us = arma::randu(2*nobs+2);
    int uind=0;
    
    if ((i % printevery == 0) && (i!=0)) {
      print_info(i,nobs,lthetacurr,lpcurr,llcurr,thsumalphas,Regions,llsumalphas,ds,rhos);
    }
    
    // Propose new theta
    lthetaprop=lthetacurr+delth;
    lpprop=log_prior(lthetaprop,primns,privars);
    eQtrprop=eQts_all(Obs,Deltat,Regions,lthetaprop,gamma,mw,absmin,absmax,S,pRates);
    eQtrm1prop=eQts_all(Obs,Deltat,Regions-1,lthetaprop,gamma,mw,absmin,absmax,S,pRates);
    llprop=ll_from_eQts_block(eQtrprop,eQtrm1prop);

    logr=lpprop-lpcurr+llprop-llcurr;
    thsumalphas += exp(min(0.0,logr));

    if (log(us(uind++))<logr) { // accept new theta
      lthetacurr=lthetaprop;
      lpcurr=lpprop;
      llcurr=llprop;
      eQtrcurr=eQtrprop;
      eQtrm1curr=eQtrm1prop;
    }

    // Single Metropolis within Gibbs for new regions
    std::vector<double> ups(nobs); // whether proposed region is r+1 or r-1
    std::vector<double> eqrnew(nobs); // relevant [e^{Qt}]_{i,j}
    
    if (us(uind++)<0.5) {
      ups[0]=0; // down
    }
    else {
      ups[0]=1; //up
    }

    for (j=1;j<nobs;j++) {
      ups[j]=ups[0];
    }

    //    #pragma omp parallel for schedule(dynamic)
    for (j=0;j<nobs;j++) {
      int d;
      double rcurr=Regions(0), rho;
      if (ups[j]==0) { // Down
	if (rcurr<=2) {
	  eqrnew[j]=0; // r-2
	}
	else {
	  arma::mat LoHi=get_LoHi(Obs.col(j),Obs.col(j+1),rcurr-2,gamma,mw,absmin,absmax);
	  eqrnew[j]=eQt_one(Obs.col(j),Obs.col(j+1),LoHi,Deltat,lthetacurr,S,pRates, &rho,&d);
	}
      }
      else {
	arma::mat LoHi=get_LoHi(Obs.col(j),Obs.col(j+1),rcurr+1,gamma,mw,absmin,absmax);
	//	cout << "Up\n";
	eqrnew[j]=eQt_one(Obs.col(j),Obs.col(j+1),LoHi,Deltat,lthetacurr,S,pRates, &rho, &d);
      }
      rhos_vec[j]=rho; ds_vec[j]=d;
    }
    if (i % printevery == (printevery-1)) {
      for (j=0;j<nobs;j++) {
	rhos(j)=rhos_vec[j];
	ds(j)=ds_vec[j];
      }
    }

    double rcurr=Regions(0);
    
    if (ups[0]==0) {
      if (rcurr>1) { // if rcurr=1 then simply reject
	arma::vec eQtrm2=arma::vec(eqrnew);
	llprop=ll_from_eQts_block(eQtrm1curr,eQtrm2);
	llsumalphas(0)=llsumalphas(0)+min(1.0,exp(llprop-llcurr));
	if (log(us(uind++))<llprop-llcurr) {
	  Regions=Regions-1;
	  eQtrcurr=eQtrm1curr;
	  eQtrm1curr=eQtrm2;
	  llcurr=llprop;
	}
      }
    }
    else {
      arma::vec eQtrp1=arma::vec(eqrnew);
      llprop=ll_from_eQts_block(eQtrp1,eQtrcurr);
      llsumalphas(0)=llsumalphas(0)+min(1.0,exp(llprop-llcurr));
      if (log(us(uind++))<llprop-llcurr) {
	Regions=Regions+1;
	eQtrm1curr=eQtrcurr;
	eQtrcurr=eQtrp1;
	llcurr=llprop;
      }
    }

    InsertInOutput(lthetacurr,llcurr+lpcurr,arma::accu(Regions),Output,i+1);
  }
  auto t2 = std::chrono::high_resolution_clock::now();

  double dnits=(double)nits;
  llsumalphas /= dnits;
  cout <<"\n***";
  //  llsumalphas.print();
  cout << "***\nAcc rates: theta = " << thsumalphas/dnits<<", obs ="<<llsumalphas.max()<<" \n";
  cout<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  cout << "Written data to file: "<<string("Output/")+outfname<<"\n";
  Output.save(string("Output/")+outfname,arma::raw_ascii);

  ofstream meta;
  meta.open(string("Output/"+outmetaname));
  meta <<"\n***";
  meta << "nits=" <<nits<<", lambda="<<lam<<", gamma="<<gamma<<", mw="<<mw<<"\n";
  llsumalphas.print(meta);
  meta << "***\nAcc rates: theta = " << thsumalphas/dnits<<", obs = "<<llsumalphas.max()<<" \n";
  meta<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  meta.close();
  
  return 0;
}
