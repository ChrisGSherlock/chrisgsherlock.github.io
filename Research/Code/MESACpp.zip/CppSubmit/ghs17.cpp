#include <iostream>
#include <armadillo>
#include <vector>
#include "MJPsystems.h"
#include "MJPget_Q.h"
#include "matexp.h"
#include <chrono>

using namespace std;

// Guido's random truncation but compatible with mine.
int parms_get_check(int argc, const char** pargv, int *pnits,
		    double *plam, double *pgamma, double *pa, int *pprintevery) {
  int bad=0;
  if (argc==1) {
    cout << "USAGE: "<< pargv[0] << " nits lambda gamma a printevery\n";
    bad=1;
  }
  if (argc>1) {
    *pnits=atoi(pargv[1]); 
  }
  if (argc>2) {
    *plam=atof(pargv[2]); 
  }
  if (argc>3) {
    *pgamma=atof(pargv[3]); 
  }
  if (argc>4) {
    *pa=atof(pargv[4]); 
  }
  if (argc>5) {
    *pprintevery=atof(pargv[5]); 
  }

  if (*pnits<0) {
    cout << "Bad nits: "<<*pnits<<"\n";
    bad=1;
  }
  if (*plam<0) {
    cout << "Bad lambda: "<< *plam<<"\n";
    bad=1;
  }
  if (*pgamma<0) {
    cout << "Bad gamma: "<< *pgamma<<"\n";
    bad=1;
  }
  if ((*pa<=0) || (*pa>=1)) {
    cout << "Bad a: "<< *pa<<"\n";
  }

  if (!bad) {
    cout << "nits=" <<*pnits<<", lam="<<*plam<<", gam="<<*pgamma<<", a="<<*pa<<", printevery="<<*pprintevery<<"\n";
  }

  return bad;
}
arma::mat grow_sqV(arma::mat sqV, int db) {
  arma::mat sqVb=arma::zeros(db,db);
  int i,j,d=sqV.n_rows;

  for (i=0;i<d;i++) {
    for (j=0;j<d;j++) {
      sqVb(i,j)=sqV(i,j);
    }
  }
  return sqVb;
}

double log_prior(arma::vec ltheta, arma::vec primns) {
  int i;
  double lp=0;
  for (i=0;i<(int)ltheta.n_elem;i++) {
    lp+=-(ltheta(i)-primns(i))*(ltheta(i)-primns(i))/2;
  }
  return lp;
}

void InsertInOutput(arma::vec lthetacurr,double lpost, double mnrg, arma::mat &Output, int iter) {
  int i, n=lthetacurr.n_elem;
  for (i=0;i<n;i++) {
    Output(iter,i)=lthetacurr(i);
  }
  Output(iter,i)=lpost;
  Output(iter,i+1)=mnrg;
}

double eQt_one(arma::vec x0, arma::vec x1, arma::mat LoHi, double deltat,
	       arma::vec lthetacurr, arma::mat S,
	       double (*pRates)(int, arma::vec, arma::vec)) {
  int ss_size=LoHi_size(LoHi); //need one extra for Coffin
  arma::vec nuin=arma::zeros(ss_size+1);
  int ind_start=LoHi_xtoj(x0, LoHi);
  int ind_end=LoHi_xtoj(x1, LoHi);
  nuin(ind_start)=1.0;
  arma::sp_mat Q = deltat*LoHi_create_Q(LoHi, exp(lthetacurr), S, pRates);
  arma::rowvec nuout = v_exp_Q(nuin.t(), Q, 1e-15);
  //  cout << "trprob="<<nuout(ind_end)<<"\n";
  return nuout(ind_end);
}

double llone_rand_trunc(arma::vec x0, arma::vec x1, double Deltat,
			arma::vec lthetacurr, double a, double gamma, int mw,
			arma::vec absmin, arma::vec absmax, arma::mat S,
			double (*pRates)(int, arma::vec, arma::vec),
			int *pnreg) {
  
  arma::mat LoHi;
  int reg=1;
  double qcomp=1; // one minus the probability of stopping next go
  double u=0.0,eQtprev=0.0,eQtthis;
  double partial_sum=0.0, pge=1; // prob(stop at this val or later)
  
  while (u <= qcomp) { 
    LoHi=get_LoHi(x0,x1,reg,gamma,mw,absmin,absmax);    
    eQtthis=eQt_one(x0,x1,LoHi,Deltat, lthetacurr, S, pRates);
    partial_sum += (eQtthis-eQtprev)/pge;
    eQtprev=eQtthis;
    qcomp*=a;
    pge*=qcomp;
    arma::vec us = arma::randu(1);
    u=us(0);
    reg++;
  }

  // if (isnan(log(partial_sum))) {
  //    cout << "sum="<<partial_sum << " x0="<<x0<<" x1="<<x1<<" reg="<<reg<<"\n";
  // exit (EXIT_FAILURE);
  //}
  *pnreg=reg-1; // just for diagnostics
  return log(partial_sum);
}
double llall_rand_trunc(arma::mat Obs, double Deltat,
			arma::vec lthetacurr, double a, double gamma, int mw,
			arma::vec absmin, arma::vec absmax, arma::mat S,
			double (*pRates)(int, arma::vec, arma::vec),
			double *pmnreg) {
  int j;
  int nobs=Obs.n_cols-1;
  arma::vec regs=arma::vec(nobs);
  double ll=0;
  int reg;
  
  for (j=0;j<nobs;j++) {
    ll+=llone_rand_trunc(Obs.col(j), Obs.col(j+1), Deltat, lthetacurr, a,gamma,
			 mw, absmin, absmax, S, pRates, &reg);
    regs(j)=(double)reg;
  }
  *pmnreg=arma::accu(regs)/(double)nobs;
  //  arma::rowvec regsr=regs.t();
  //regsr.print();
  //  cout << "ll="<<ll<<"\n";
  return ll;
}


int main(int argc, const char** pargv)  {
  int nits=1, printevery=100;
  double gamma=0.1, lam=1.0, a=0.95; // defaults
  //***********************************
  //** Uncomment/comment the below depending on which model you're using
  //    string rootname="LV10";
  string rootname="LV20";
  //    string rootname="LV40";
  //string rootname="Sch50";
  //  string rootname="AR50GWLo";

  //  string sqvname="Identity"; // Identity - use for initial run
  string sqvname="ReadMatrix"; // Read it in
  //**********************************
  double Deltat, nr;
  int mmw;
  arma::dmat S;
  arma::dvec thetainit, primns, privars; 
  double (*pRates)(int, arma::vec, arma::vec);

  if ((rootname=="LV10") || (rootname=="LV20") || (rootname=="LV40")) {
    Deltat=1.0; mmw=1; nr=LV_nr; S=LV_S;
    thetainit={0.3,0.4,0.01}; 
    primns={.2,.2,.02}; // LV prior means
    privars={1.0,1.0,1.0,}; // LV
    pRates=&LV_Rates;
  }
  else if (rootname=="Sch50") {
    Deltat=4.0; mmw=0; nr=Schlogel_nr; S=Schlogel_S;
    thetainit={3.0,0.5,0.5,3.0}; // Schlogel
    primns={1.0,1.0,1.0,1.0}; // Schlogel
    privars={1.0,1.0,1.0,1.0}; // Sch
    pRates=&Schlogel_Rates;
  }
  else if (rootname=="AR50GWLo") {
    Deltat=1.0; mmw=2; nr=Autoreg_nr; S=Autoreg_S;
    thetainit={0.1,0.7,0.70,0.2,0.1,0.9,0.3,0.1,2.0};//AutoReg
    primns={.2,.2,.2,.2,.2,.2,.2,.2,10.0}; // Autoreg
    privars={1.0,1.0,1.0,1.0,0.1,1.0,1.0,1.0,1.0}; // Autoreg
    pRates=&Autoreg_Rates;
  }
  else {
    cout << "Bad rootname: "<<rootname<<"\n";
    return -1;
  }

 if (rootname=="LV10") {
    Deltat=2.0; 
  }
  else if (rootname=="LV40") {
    Deltat=0.5; 
  }
  const int ns=S.n_rows;
  arma::vec absmin=arma::zeros(ns), absmax=absmin-1; // LV or Autoreg. or Schlog
  if (rootname=="AR50GWLo") {
    absmax(3)=thetainit(8); // Autoreg. has ub on DNA, LV/Sch has no ubs
  }
  //*********************************************************************
  primns=log(primns); // prior is on log theta
  arma::mat sqV, Obs;
  string obsfname="Data/"+rootname+"data.csv";
  Obs.load(obsfname);
  Obs=Obs.t();

  const int  nobs=Obs.n_cols-1;
  if (sqvname != "Identity") {
    sqvname="Data/"+rootname+"sqV.txt";
    sqV.load(sqvname);
  }
  else {
    sqV=arma::mat(arma::diagmat(arma::ones(nr)));// Id - use initially
  }
  if (thetainit.n_elem > sqV.n_rows) {
    sqV=grow_sqV(sqV,thetainit.n_elem);
  }
  const int nz=sqV.n_rows;
  arma::mat Output;
  arma::vec Regions=arma::ones(nobs);
  arma::vec lthetacurr=log(thetainit);
  arma::vec lthetaprop=arma::vec(nz);
  double llcurr, llprop, lpcurr, lpprop;
  int i, bad;
  double thsumalphas=0, llsum=0, ll2sum=0, mnreg; // sum of acc. probs
  arma::rowvec llsumalphas=arma::zeros(1,nobs);
  arma::arma_rng::set_seed_random();
  
  arma::arma_version ver;
  cout << "ARMA vn: "<< ver.as_string() << "\n\n";
  bad=parms_get_check(argc, pargv, &nits, &lam, &gamma, &a, &printevery);
  if (bad) {
    return 0;
  }
  string outfname="ghs"+rootname+ "L" + to_string((int) (lam*100))+"G"+to_string((int)(gamma*100))+"a"+to_string((int)(a*1000))+".txt";

  cout << "Obs="<<obsfname<<", Deltat=" << Deltat <<"\n";
  cout << "sqV="<<sqvname<<"\n"<<sqV<<"\n";

  auto t1 = std::chrono::high_resolution_clock::now();
  
  Output=arma::zeros(nits+1,nz+2);
  lpcurr=log_prior(lthetacurr,primns);

  llcurr=llall_rand_trunc(Obs, Deltat, lthetacurr, a, gamma, mmw,absmin,absmax,
			  S, pRates, &mnreg);
  InsertInOutput(lthetacurr,llcurr+lpcurr,mnreg,Output,0);
  llsum += llcurr; ll2sum+= llcurr*llcurr;
  
  for (i=0;i<nits;i++) {
    double logr, di=(double)i;
    arma::mat delth = lam*sqV*arma::randn(nz);
    arma::vec us = arma::randu(1);
 
    if ((i % printevery == 0) && (i!=0)) {
        cout << "\n**Iteration="<<i<<"\n";
	cout << lthetacurr.t();
	cout << "llcurr="<<llcurr<< ", llprop="<<llprop<<"\n";
	cout << "lpcurr="<<lpcurr<< ", lpprop="<<lpprop<<"\n";
	cout << "Acc rate for theta = " << thsumalphas/di<<"\n";
    }
    // Propose new theta
    lthetaprop=lthetacurr+delth;
    lpprop=log_prior(lthetaprop, primns);
    llprop=llall_rand_trunc(Obs, Deltat, lthetaprop,a,gamma,mmw, absmin, absmax,
			    S, pRates, &mnreg);

    logr=lpprop-lpcurr+llprop-llcurr;
    thsumalphas += min(1.0,exp(logr));

    if (log(us(0))<logr) { // accept new theta
      lthetacurr=lthetaprop;
      lpcurr=lpprop;
      llcurr=llprop;
    }
    llsum+=llprop; ll2sum+=llprop*llprop;
    InsertInOutput(lthetacurr,llcurr+lpcurr,mnreg,Output,i+1);
  }
  auto t2 = std::chrono::high_resolution_clock::now();

  double dnits=(double)nits;
  cout <<"\n***";
  cout << "***\nAcc rate for theta = " << thsumalphas/dnits<<"\n";

  cout<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  double denom=(double)(nits+1);
  cout << "var of ll="<<ll2sum/denom-(llsum/denom)*(llsum/denom)<<"\n";
  cout << "mean of ll="<<llsum/denom<<"\n";

  cout << "Written data to file: "<<string("Output/")+outfname<<"\n";
  Output.save(string("Output/")+outfname,arma::raw_ascii);

  return 0;
}
