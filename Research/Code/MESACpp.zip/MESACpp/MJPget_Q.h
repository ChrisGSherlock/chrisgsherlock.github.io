// Generic full or Truncated statespace
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, double gamma, int mw, arma::vec absmin, arma::vec absmax);
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, double gamma, int mw=1);
arma::cube get_LoHiR1s(arma::mat Obs, int window=8);
arma::mat get_LoHigR1(arma::vec xslo, arma::vec xshi, int region, double gamma, int mw, arma::vec absmin, arma::vec absmax);
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, arma::vec gammas, int mw, arma::vec absmin, arma::vec absmax);
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2, int region, arma::vec gammas, int mw=1);
arma::mat get_LoHi(arma::vec xs1, arma::vec xs2);
int LoHi_size(arma::mat LoHi);
int LoHi_x_in_range(arma::vec xs, arma::mat LoHi);
int LoHi_xtoj(arma::vec xs, arma::mat LoHi);
arma::Col<double> LoHi_jtox(int j, arma::mat LoHi);
arma::sp_mat LoHi_create_Q(arma::mat LoHi, arma::vec thetas, const arma::mat S,
			   double (*pRates)(int, arma::vec, arma::vec));

// SIR and SEIR full statespace
int SIR_x_in_range(arma::vec xs, int npop); // also works for SIRS
int SEIR_x_in_range(arma::vec xs, int npop); // also works for SEIRS
int SIR_xtoj(arma::vec xs, int npop);  // also works for SIRS
int SEIR_xtoj(arma::vec xs, int npop); // also works for SEIRS
arma::Col<double> SIR_jtox(int j, int npop);
arma::Col<double> SEIR_jtox(int j, int npop);
arma::sp_mat SIR_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
			      double (*pRates)(int, arma::vec, arma::vec));
arma::sp_mat SEIR_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
			       double (*pRates)(int, arma::vec, arma::vec));
arma::sp_mat SEIRS_create_Qfull(int npop, arma::vec thetas, const arma::mat S,
				double (*pRates)(int, arma::vec, arma::vec));

// SIR birth-process statespace
arma::mat SIRbirth_get_LoHi(arma::vec x0, arma::vec x1);
int SIRbirth_x_in_range(arma::vec xs, arma::vec x0, arma::mat LoHi);
int SIRbirth_xtoj(arma::vec xs, arma::vec x0, arma::mat LoHi);
arma::vec SIRbirth_jtox(int j, arma::vec x0, arma::mat LoHi);
arma::sp_mat SIRbirth_create_Q(arma::vec x0, arma::mat LoHi, arma::vec thetas,
			       const arma::mat S,
			       double (*pRates)(int, arma::vec, arma::vec));



