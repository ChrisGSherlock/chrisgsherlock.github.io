library("coda")


### Give a filename (without the .txt append)

fname="nMESASch50L902G40MW20"
##fname="MESALV20L1500G10MW20"
a=read.table(file=paste(fname,".txt",sep=""))


### Pick the truth to overlay on the trace/density plot

##truths=log(c(.3,.4,.01)) ## LV
##truths=log(c(.1,.7,.7,.2,.1,.9,.3,.1)) ## AR
truths=log(c(3,.5,.5,3)) ## Sch


### Decide whether you want trace/density or bivariate scatter plots
trace=0
dens=0
scat=1; cex=.05

### What size grid of plots?
downplot=2
crossplot=3

b=a[100:nrow(a),]
main=fname

logdens=0 ## do we want the final plot forced to be of log \pi?
if (logdens) {
    fin=ncol(a)-1
} else {
    fin=ncol(a)
}

nparm=downplot*crossplot-1
par(mfrow=c(downplot,crossplot))
if (trace) {
    for (i in 1:nparm) {
        plot(b[,i],type="l",main=main)
        abline(h=truths[i],col=2)
    }
    plot(b[,fin],type="l",main=main)
}
if (dens) {
    for (i in 1:nparm) {
        plot(density(b[,i]),main=main)
        abline(v=truths[i],col=2)
    }
    plot(density(b[,fin]),main=main)
    n=nrow(b)
    print(t(rep(1/n,n))%*%as.matrix(b))
}
if (scat) {
    plot(b[,1],b[,2],cex=cex,main=main)
    plot(b[,1],b[,3],cex=cex)
    plot(b[,2],b[,3],cex=cex)
    plot(b[,1]+b[,2]+b[,3],b[,fin],cex=cex)
    if (nparm>3) {
        plot(b[,1],b[,4],cex=cex)
        plot(b[,2],b[,4],cex=cex)
    }
    if (nparm>5) {
        plot(b[,3],b[,4],cex=cex)
    }
}

### Work out effective sample sizes

ESS=effectiveSize(as.mcmc(b))
print(ESS)
