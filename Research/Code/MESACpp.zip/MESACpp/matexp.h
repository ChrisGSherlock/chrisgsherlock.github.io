// Raw Unif and SS algorithms
arma::mat Unif_v_exp_Q(const arma::mat v, const arma::sp_mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat Unif_v_exp_Q(const arma::mat v, const arma::mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat SS_exp_Q(const arma::sp_mat Q, double prec, bool renorm=true, bool t2=true, int *pm=NULL);
arma::mat SS_exp_Q(const arma::dmat Q, double prec, bool renorm=true, bool t2=true, int *pm=NULL);
arma::mat SS_v_exp_Q(const arma::mat v, const arma::sp_mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat SS_v_exp_Q(const arma::mat v, const arma::mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
// Automatic choice between SS and Unif
arma::mat v_exp_Q(const arma::mat v, const arma::sp_mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat v_exp_Q(const arma::mat v, const arma::mat Q, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat vT_exp_Q(const arma::dvec &v, const arma::sp_mat &Q, double prec, bool renorm=true, bool t2=true, int *pm=NULL);
arma::mat vT_exp_Q(const arma::dvec &v, const arma::dmat &Q, double prec, bool renorm=true, bool t2=true, int *pm=NULL);

arma::mat SPS_exp_spQ_v(const arma::sp_mat Q, const arma::mat v, double prec, bool ren=true, bool tt=true, int *pm=NULL);
arma::mat MUSPS_exp_spQ_v(arma::sp_mat Q, arma::vec v, double prec, arma::vec ts);
arma::mat MUSPS_v_exp_spQ(arma::rowvec v, arma::sp_mat Q, double prec, arma::vec ts);
int get_m(double rho, double prec, int mlo=-1);

arma::dvec Krylov_exp_Q_v(const arma::dvec &v, const arma::sp_mat &Q);
arma::dvec Krylov_exp_Q_v(const arma::dvec &v, const arma::dmat &Q);
arma::dmat Krylov_vt_exp_Q(const arma::dvec &v, const arma::sp_mat &Q);
arma::dmat Krylov_vt_exp_Q(const arma::dvec &v, const arma::dmat &Q);



