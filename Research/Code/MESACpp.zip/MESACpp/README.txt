This directory contains code for: MESA, nMESA and ghs17.

You will need the Armadillo linear algebra library as well as openBLAS and LAPACK and boost. My results were obtained using vn 8.4 of Armadillo. Later versions are, apparently, faster; if you have a later version you may observe a larger improvement over particle MCMC than in the paper.

Compile source by
./comp nMESA
./comp MESA
./comp ghs17

Type
./nMESA
./MESA
./ghs17
to see instructions for call arguments. The only two that are not self-explanatory are:

printevery	    specifies how frequently you'd like progress output sent to the screen (e.g. current iteration number). Provide an integer such as 100.

model		    this can be one of LV20 LV10 LV40 Sch50 or AR50GWLo. 

The MCMC output is in Output/NAME.txt, created at the end of the run. The run also creates a Output/NAME.info file containing the parameters/timing etc. NAME is created according to the algorithm and the parameter values chosen.

Currently the code reads in the square root of a variance matrix (that will then be multiplied by the scaling parameter, lambda). 
If you decide to create your own data and run on that then you may not have a (sqrt) variance matrix to hand. The code contains the facility to use the appropriate identity matrix - you'll need to comment and uncomment a line each in the code (MESA ~line 198/199, nMESA ~line 190/191, GHS17 line 173/174). See the code for instructions.

Chris Sherlock
19.12.2019

Updates:
15.11.2021: make ghs17 like MESA and nMESA - now no need to edit the file, and it produces a .info file automatically.


