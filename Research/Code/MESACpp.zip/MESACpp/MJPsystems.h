double LV_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> LV_S={{-1,0,1},{0,1,-1}};
const int LV_nr=3;

double LVim_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> LVim_S={{-1,0,1,1},{0,1,-1,0}};

double Autoreg_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> Autoreg_S={{0,0,1,0,0,0,-1,0},
				   {0,0,0,1,-2,2,0,-1},
				   {-1,1,0,0,1,-1,0,0},
				   {1,-1,0,0,0,0,0,0}};
//      redundant		   {-1,1,0,0,0,0,0,0}};
const int Autoreg_nr=8;

double Schlogel_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> Schlogel_S={{+1,-1}};
const int Schlogel_nr=4;

double SIR_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> SIR_S={{-1,0},{1,-1}};
double SEIR_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> SEIR_S={{-1,0,0},{1,-1,0},{0,1,-1}};
double SEIRS_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> SEIRS_S={{-1,0,0,1},{1,-1,0,0},{0,1,-1,0}};

double Moran_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> Moran_S=arma::rowvec({+1,-1});

double ImmDeath_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas);
const arma::Mat<double> ImmDeath_S=arma::rowvec({+1,-1});
arma::vec ImmDeath_Truth(double T, int x0, arma::vec thetas);
// Currently hardwired for x0=npop



