#include <iostream>
#include <armadillo>
#include <math.h>

using namespace std; // need for the accurate lgamma

double LV_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  
  if (r==0) {
    rat=thetas(0)*xs(0); // predator dies
  }
  else if (r==1) {
    rat=thetas(1)*xs(1); // prey reproduces
  }
  else if (r==2) {
    rat=thetas(2)*xs(0)*xs(1); // predator eats prey and reproduces
  }
  return rat;
}
double LVim_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  
  if (r==0) {
    rat=thetas(0)*xs(0);
  }
  else if (r==1) {
    rat=thetas(1)*xs(1);
  }
  else if (r==2) {
    rat=thetas(2)*xs(0)*xs(1);
  }
  else if (r==3) {
    rat=thetas(3); // Immigration of predators.
  }
  return rat;
}


// From Golightly and Wilkinson 2005
// x0= RNA, x1= P, x2=P2, x3=DNA.P2, x4=thetas(8)-x3=DNA
double Autoreg_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;

  if (r==0) {
    rat=thetas(0)*(thetas(8)-xs(3))*xs(2);
  }
  else if (r==1) {
    rat=thetas(1)*xs(3);
  }
  else if (r==2) {
    rat=thetas(2)*(thetas(8)-xs(3));
  }
  else if (r==3) {
    rat=thetas(3)*xs(0);
  }
  else if (r==4) {
    rat=thetas(4)*xs(1)*(xs(1)-1)/2;
  }
  else if (r==5) {
    rat=thetas(5)*xs(2);
  }
  else if (r==6) {
    rat=thetas(6)*xs(0);
  }
  else if (r==7) {
    rat=thetas(7)*xs(1);
  }
  return rat;
}
double Schlogel_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  double x=xs[0];
  if (r==0) {
    rat=thetas(0)*x*(x-1)/2.0+thetas(2);
  }
  else if (r==1) {
    rat=thetas(1)*x*(x-1)*(x-2)/6.0+thetas(3)*x;
  }
  //  else if (r==2) {
  //   rat=thetas(2);
  //}
  //else if (r==3) {
  //  rat=thetas(3)*x;
  //}
  return rat;
}


double SIR_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  
  if (r==0) { // S+I->2I
    rat=thetas(0)*xs(0)*xs(1);
  }
  else if (r==1) { // I->R
    rat=thetas(1)*xs(1);
  }
  return rat;
}
double SEIR_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  
  if (r==0) { // S+I->E+I
    rat=thetas(0)*xs(0)*xs(2);
  }
  else if (r==1) { // E->I
    rat=thetas(1)*xs(1);
  }
  else if (r==2) { // I->R
    rat=thetas(2)*xs(2);
  }
  return rat;
}
double Moran_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  double alpha=thetas(0), beta=thetas(1), u=thetas(2), v=thetas(3), N=thetas(4);
  double f=xs(0)/N;
  
  if (r==0) { // n->n+1
    rat=(1-f)*(alpha*f*(1-u)+beta*(1-f)*v);
  }
  else if (r==1) { // n->n-1
    rat=f*(alpha*f*u+beta*(1-f)*(1-v));
  }
  return rat;
}
// Tractable, finite-space immigration-death process
double ImmDeath_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  double gamma=thetas(0), mu=thetas(1), npop=thetas(2);
  
  if (r==0) { // n->n+1
    rat=gamma*(npop-xs(0));
  }
  else if (r==1) { // n->n-1
    rat=mu*xs(0);
  }
  return rat;
}
arma::vec ImmDeath_Truth(double T, int x0, arma::vec thetas) {
  // Currently hardwired for x0=npop
  const int npop=(int)(thetas(2)+.01);
  const long double lT=(long double) T;
  const long double ldnpop=(long double)npop;
  const long double ldmu=(long double) thetas(1);
  const long double ldgamma=(long double) thetas(0);
  const long double p=(ldgamma+ldmu*exp(-(ldgamma+ldmu)*lT))/(ldgamma+ldmu);
  int j;
  arma::vec ptrue=arma::vec(npop+1);

  for (j=0;j<=npop;j++) {
    long double ldj=(long double) j;
    long double lcomb=lgamma(ldnpop+1.0)-lgamma(ldj+1.0)-lgamma(ldnpop-ldj+1.0);
    long double lpj=lcomb+ldj*log(p)+(ldnpop-ldj)*log(1-p);
    ptrue(j)=(double)exp(lpj);
  }
  return ptrue;
}
double SEIRS_Rates(int r, arma::Col<double> xs, arma::Col<double> thetas) {
  double rat=-1.0;
  
  if (r==0) { // S+I->E+I
    rat=thetas(0)*xs(0)*xs(2);
  }
  else if (r==1) { // E->I
    rat=thetas(1)*xs(1);
  }
  else if (r==2) { // I->R
    rat=thetas(2)*xs(2);
  }
  else if (r==3) { // R->S
    rat=thetas(3)*(thetas(4)-xs(0)-xs(1)-xs(2));
  }
  return rat;
}

/*
int main(int argc, const char** pargv) {
  double rat;
  arma::Col<double> xs={1,2};
  arma::Col<double> thetas={.1,.2,.3};
  std::cout << LV_S << "\n";
  rat=LV_Rates(2,xs,thetas);
  std::cout << rat << "\n";
  return 0;
}
*/
