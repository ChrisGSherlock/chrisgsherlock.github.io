README for AAPS

This will all eventually go on GitHub and with a more full help.

You will need the library Eigen installed.

To compile: in the AAPS directory type

./compAAPSnomem

Type

./AAPSnomem

To see the options. For example, to run on the 10d test target for 10000 iterations, printing every 1000 iterations, using K=5, Wtype=3 and epsilon=1.2 use

./AAPSnomem 0 10000 1000 1 0 3 1.2 5

Output appears in the Output directory.

Chris Sherlock
17/12/2021

