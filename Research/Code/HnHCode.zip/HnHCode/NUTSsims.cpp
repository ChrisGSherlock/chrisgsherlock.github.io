#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "toy_targets.h"
#include "binary_data.h"
#include "NUTS.h"
#include "target_set.h"

using namespace std;
using namespace Eigen;



int main(int argc, const char** pargv)  {
  int targ=0, nits=1, thin=1, prt=1, precon=0, k=1, bad;
  double par1=0.0; // epsilon

  if (argc==1) {
    cout << pargv[0] <<" targ(0) nits(1) prt(1) thin(1) precon(0) eps(0.0)\n";
    cout << "Defaults in brackets.\n";
    targsprt();
    cout << "nits=#iterations, print every *prt* iterations, thin=thinning factor.\n";
    cout << "precon=0 => no preconditioning, precon=1 => full preconditioning.\n";
    return 0;
  }

  if (argc>k) { 
    targ=atoi(pargv[k++]);
  }
  if (argc>k) {
    nits=atoi(pargv[k++]);
  }
  if (argc>k) {
    prt=atoi(pargv[k++]);
  }
  if (argc>k) {
    thin=atoi(pargv[k++]);
  }
  if (argc>k) {
    precon=atoi(pargv[k++]);
  }
  if (argc>k) {
    par1=atof(pargv[k++]); // epsilon
  }

  bad=CheckInputs(targ,nits,prt,thin,precon,par1);
  if (bad==1) return 0;
  
  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> StdUnif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  // Create suitable variables for all algorithms
  ArrayXd x0, thetall, thetapri, scales;
  ArrayXd Mdiag;  // diagonal preconditioning for HMC 
  string targstr;
  Targd prior, likelihood;

    // Set up everything to do with the target
  targset(targ, x0,thetapri,thetall,scales, prior,likelihood,targstr,
	  gen, StdNormal, StdUnif);
  cout << targstr << "\n";

  if (precon) {
    Mdiag=1/scales/scales;
  }
  else {
    Mdiag=ArrayXd::Constant(scales.size(),1.0);
  }
  
  NUTS(nits, x0, par1, Mdiag, prior, likelihood, targstr,"Output/", thin, prt);

  return 0;
}

