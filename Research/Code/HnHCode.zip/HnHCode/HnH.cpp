#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "/home/sherlocc/Research/Generic_c/Targets/toy_targets.h"

using namespace std;
using namespace Eigen;

// Generic

static void InsertInOutput(Eigen::ArrayXd &x, double lpost, 
			   Eigen::ArrayXXd &Output, int &row) {
  int d=x.size();
  Output.row(row).head(d)=x; // 0 to d-1
  Output.row(row++)(d)=lpost; // d
}



static void PrintInfo(int it, double lpri, double ll, const ArrayXd &x,
		      int naccHug, int naccHop)
{
  double di=(double)(it+1);
  cout << "**Iteration="<<it+1<<"\n";
  cout << "lprior="<<lpri<<", ll="<<ll<<", lpost="<<lpri+ll<<"\n";
  cout << "x="<<x.transpose()<<"\n";
  cout << "alphaHug="<<(double)naccHug/(di-1)<<", alphaHop="<<(double)naccHop/(di-1)<<"\n";
}


// Alter x and v as it goes.
static void reflections(const int B, const double delta,
			ArrayXd &x, ArrayXd &v, const ArrayXd &Sigdiag,
			const bool precon, Targd &prior, Targd &likelihood) {
  ArrayXd g, ghat, tmp;
  int b;
  // First half step
  x+=0.5*delta*v;

  // Main set (if L>1)
  for (b=0;b<B;b++) {
    g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array();
    if (precon) {
      tmp=Sigdiag*g;
    }
    else {
      tmp=g;
    }
    v=v-2*(v*g).sum()/((g*tmp).sum())*tmp;
    x+=delta*v;
  }

  // Gone too far, so remove last bit
  x-=0.5*delta*v;
}

// Currently assumes no preconditioning
void HopPropose(ArrayXd &xprop, const ArrayXd &xcurr,
		const double lambda, const double mu,
		const ArrayXd &gcurr, const ArrayXd &Sigsqrt, const bool precon,
		mt19937 &gen, normal_distribution<double> StdNormal) {
  int d=xcurr.size();
  double gnorm, mg;
  ArrayXd ghat;

  if (precon) {
    ArrayXd gtrans=Sigsqrt*gcurr;
    gnorm=gtrans.matrix().norm();
    ghat=gtrans/gnorm;
  }
  else {
    gnorm=gcurr.matrix().norm();
    ghat=gcurr/gnorm;
  }

  mg= gnorm>1.0?gnorm:1.0; //max(1,||g||)

  ArrayXd zs=StdNormalAXd(d,gen,StdNormal);
  ArrayXd zpara=(zs*ghat).sum()*ghat;
  ArrayXd zperp=zs-zpara;

  if (precon) {
    xprop=xcurr+Sigsqrt*(lambda*zpara+mu*zperp)/mg;
  }
  else {
    xprop=xcurr+(lambda*zpara+mu*zperp)/mg;
  }
}
double HopPropldens(const ArrayXd &xprop, const ArrayXd &xcurr,
		    const double lambda, const double mu,
		    const ArrayXd &gcurr, const ArrayXd &Sigsqrt,
		    const bool precon) {
  int d=xcurr.size();
  double gnorm, mg;
  ArrayXd ghat, xs;
  
  if (precon) {
    ArrayXd gtrans=Sigsqrt*gcurr;
    gnorm=gtrans.matrix().norm();
    ghat=gtrans/gnorm;
    xs=(xprop-xcurr)/Sigsqrt;
  }
  else {
    gnorm=gcurr.matrix().norm();
    ghat=gcurr/gnorm;
    xs=xprop-xcurr;
  }

  mg= gnorm>1.0?gnorm:1.0; //max(1,||g||)

  ArrayXd xpara=(xs*ghat).sum()*ghat;
  ArrayXd xperp=xs-xpara;
  double ll=(double)d*log(mg);
  ll+=-0.5*xpara.matrix().squaredNorm()/lambda/lambda*mg*mg;
  ll+=-0.5*xperp.matrix().squaredNorm()/mu/mu*mg*mg;

  return ll;
}

// Hug and Hop
// If HopsPerHug<0 then just do one hop and no hugs
void HnH(const int nits, const ArrayXd &x0,
	 const double T, const int B, const double lambda, const double kappa,
	 const ArrayXd &Sigdiag, const bool jitter, 
	 Targd &prior, Targd &likelihood, 
	 const string outroot="", const string outpath="./",
	 const int HopsPerHug=1, const int thin=1, const int prt=0) {
  const int d=x0.size(), nout=1+nits/thin;
  int outrow=0; // stored output row
  ArrayXXd Output(nout,d+1);
  ArrayXd xcurr=x0, xprop, v;
  int i, j, naccHug=0, naccHop=0;
  bool precon=((Sigdiag-ArrayXd::Constant(d,1.0)).matrix().squaredNorm()>1e-5);
  ArrayXd Sigsqrt=Sigdiag.sqrt();
  string outfnameroot="HnH"+outroot+ "T" +to_string((int)(T*100))+"B"+to_string(B) +"J"+to_string((int)jitter)+ "lam"+to_string((int)(lambda*100))+"kap"+to_string((int)(kappa*100))+ "A"+to_string((int) precon)+"HpH"+to_string(HopsPerHug);
  string outfname=outfnameroot+".txt";
  string outiname=outfnameroot+".info";

  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> Unif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  double llcurr=likelihood.l_fn(xcurr),llprop;
  double lpricurr=prior.l_fn(xcurr),lpriprop;
  double lalpha, lallcurr, lallprop;
  double mu=pow(lambda*kappa,0.5);
  double delta=T/(double) B;
  
  InsertInOutput(xcurr,lpricurr+llcurr,Output, outrow);  

  auto t1 = std::chrono::high_resolution_clock::now();

  for (i=0;i<nits;i++) {
    if (((i+1) % prt == 0) && (i!=0)) {
      PrintInfo(i,lpricurr,llcurr,xcurr,naccHug,naccHop);
    }
    
    // Hug
    if (HopsPerHug>=0) {
      double delthis=delta;
      if (jitter) {
	delthis=delta*(0.8+0.4*Unif(gen));
      }

      v=StdNormalAXd(d,gen,StdNormal)*Sigsqrt; 
      lallcurr=lpricurr+llcurr-0.5*(v*v/Sigdiag).sum();

      // This alters xprop and v
      xprop=xcurr;
    //        cout << xprop.t()<<"\n";
      reflections(B, delthis, xprop, v, Sigdiag, precon, prior, likelihood);
      //        cout << xprop.t()<<"\n";
      llprop=likelihood.l_fn(xprop);
      lpriprop=prior.l_fn(xprop);
      lallprop=lpriprop+llprop-0.5*(v*v/Sigdiag).sum();
    
      lalpha=lallprop-lallcurr;

      if (log(Unif(gen))<lalpha) { // accepted
	naccHug++;
	xcurr=xprop; llcurr=llprop; lpricurr=lpriprop; 
      }
    }

    // Hop
    for (j=0;j<abs(HopsPerHug); j++) {
      ArrayXd gcurr=prior.gl_fn(xcurr)+likelihood.gl_fn(xcurr);
      HopPropose(xprop,xcurr,lambda,mu,gcurr,Sigsqrt,precon,gen,StdNormal);
      llprop=likelihood.l_fn(xprop);
      lpriprop=prior.l_fn(xprop);
      ArrayXd gprop=prior.gl_fn(xprop)+likelihood.gl_fn(xprop);

      lallcurr=lpricurr+llcurr+HopPropldens(xprop,xcurr,lambda,mu,gcurr,
					    Sigsqrt,precon);
      lallprop=lpriprop+llprop+HopPropldens(xcurr,xprop,lambda,mu,gprop,
					    Sigsqrt,precon);

      lalpha=lallprop-lallcurr;

      if (log(Unif(gen))<lalpha) { // accepted
	naccHop++;
	xcurr=xprop; llcurr=llprop; lpricurr=lpriprop;
      }
    }
    
    if ((i+1) % thin == 0) {
      InsertInOutput(xcurr,llcurr+lpricurr,Output,outrow);
    }
  }
  auto t2 = std::chrono::high_resolution_clock::now();

  ofstream outf, outi;
  outf.open(string(outpath+outfname));  
  outf<<Output;
  outf.close();

  double dnits=(double)nits, dnaccHug=(double)naccHug, dnaccHop=(double)naccHop;
  outi.open(string(outpath+outiname));
  outi <<"\n***";
  outi << "nits=" <<nits<<", B="<<B<<", del="<<delta<<", jitter="<<jitter<<", lam="<<lambda<<", mu="<<mu<<", precon="<<precon<<"\n";
  outi << "***\nAccHug = " << dnaccHug/dnits<<"AccHop = "<<dnaccHop/dnits<<"\n";
  outi<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  outi.close();
  cout << "outfiles: "<<outfname<<" and "<<outiname<<"\n";
}

