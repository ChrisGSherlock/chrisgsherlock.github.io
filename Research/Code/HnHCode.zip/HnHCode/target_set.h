void targset(const int targ, Eigen::ArrayXd &x0, Eigen::ArrayXd &thetapri, Eigen::ArrayXd &thetall, Eigen::ArrayXd &scales, Targd &prior, Targd &likelihood, std::string &targstr, std::mt19937 gen, std::normal_distribution<double> StdNormal, std::uniform_real_distribution<double> StdUnif);

void targsprt(void);
