library(coda)

##fname="nutsIso_Pr_eps40A0.txt"
##fname="nutsStr_QG_eps10A0.txt"
##fname="HnHStr_G_del30B5J0lam60mu10A1.txt"

fname="HnHCau_1000C30_T60B5J1lam1200kap50A0HpH1.txt"
##fname="NUTSCau_1000C30_eps11A0.txt"
##fname="HMCCau_1000C100_T8L14J1A0.txt"
fname="HnHPowT400B10J1lam100kap50A0HpH1.txt"
fname="HMCPowT40L10J1A1.txt"
fname="HMCRasch_100R20_T10L5J1A1.txt"
fname="NUTSRasch_100R20_eps25A1.txt"
##fname="HnHRasch_100R20_T120B5J1lam1500kap25A1HpH1.txt"
a=read.table(file=fname)
its=1:nrow(a)
##its=1:200
task="trace"
##task="density"
##task="QQ"
a=a[its,]

cpts=c(1,2,3,10,25,26)
cpts=c(1:5,11)
cpts=c(1,19,100,101,119,120)
ncpt=length(cpts)

par(mfrow=c(3,2))
for (i in 1:ncpt) {
    cp=cpts[i]
    if (task=="density") {
        plot(density(a[,cp]),main=cp)
    }
    if (task=="trace") {
        plot(a[,cp],type="l",main=cp)
    }
    if (task=="QQ") {
        qqnorm(a[,cp],main=cp)
        qqline(a[,cp])
    }
}

ees=effectiveSize(as.mcmc(a))

ees
M=100;N=20
min(ees[1:(length(ees)-1)])
min(ees[1:M]) ## Rasch etas
min(ees[(M+1):(M+N)]) ## Rasch betas

if (F) {  ## For the Rasch-model output
    par(mfrow=c(1,1))
    M=100; N=20; tot=M+N
    plot(c(1,tot),c(1,tot),col="white")
    C=cor(a[,1:tot])
    diag(C)=0
    for (i in 1:tot) {
        points(1:tot,rep(i,tot),cex=C[i,]*2)
    }
    mean(C[1:M,1:M])*M/(M-1)
    mean(C[(M+1):tot,(M+1):tot])*N/(N-1)
    mean(C[(M+1):tot,1:M])*M/(M-1)
}
