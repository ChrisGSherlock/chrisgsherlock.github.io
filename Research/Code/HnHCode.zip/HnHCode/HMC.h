void HMC(const int nits, const Eigen::ArrayXd &x0,
	 const double T, const int L, const Eigen::ArrayXd &Mdiag,
	 const bool Tjitter, Targd &prior, Targd &likelihood,
	 const std::string outroot="", const std::string outpath="./",
	 const int thin=1, const int prt=0);


