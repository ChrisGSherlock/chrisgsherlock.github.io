#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <random>
#include "/home/sherlocc/Research/Generic_c/Targets/toy_targets.h"
#include "/home/sherlocc/Research/Generic_c/Targets/binary_data.h"
#include "target_set.h"

using namespace std;
using namespace Eigen;

void targsprt(void) {
  cout << "Targs (d=25):\n0=Gaussian, 2=logis*Gauss, 4=quartic*Gauss, \n6=banana, 8=bimodal, 10=PlusPrism,\n12-14 Cauchit regression (d=10,30,100), 15=Rasch.\n Scales of 1, unless +1 for scale(i)=d+1-i.\n";
}

void targset(const int targ, ArrayXd &x0, ArrayXd &thetapri, ArrayXd &thetall, ArrayXd &scales, Targd &prior, Targd &likelihood, string &targstr, std::mt19937 gen, std::normal_distribution<double> StdNormal, std::uniform_real_distribution<double> StdUnif) {
  int targ_type, d;
  
  if (targ<12) {
    d=25;
    double max_ecc=(double) 10;
    bool stretched;
    targ_type=targ/2;
    stretched=targ-2*targ_type;

    if (stretched) {
      scales=Eigen::ArrayXd::LinSpaced(d,max_ecc,1.0);
      targstr="Str";
      cout << "Scales linear from "<<max_ecc<<" to 1"<<endl; 
    }
    else {
      scales=Eigen::ArrayXd::Zero(d)+1.0;
      targstr="Iso";
      cout << "Scales all 1\n";
    }
    prior.theta=ArrayXd::Zero(1); // any value as is irrelevant
    prior.pl_fn=&l_null;
    prior.pgl_fn=&gl_null;
  }
  else if (targ<15) {
    targstr="Cau";
    targ_type=targ;
  }
  else {
    targstr="Rasch";
    targ_type=targ;
  }

  if (targ_type==0) { // Gaussians
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z;
    thetall=ArrayXd::Zero(2*d);
    thetall.tail(d) = scales*scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_GaussDiag;
    likelihood.pgl_fn=&gl_GaussDiag;
    targstr.append("_G_");  
    cout << "Gaussian\n";
  }
  else if (targ_type==1) { // Logistic * Gauss
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z*1.81; // not quite right (has ~right variance)
    thetall=ArrayXd::Zero(d+1);
    thetall(0)=5; // a
    thetall.tail(d) = scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_LogisticGaussCpts;
    likelihood.pgl_fn=&gl_LogisticGaussCpts;
    targstr.append("_LG_");  
    cout << "Logistic*Gaussian\n";
  }
  else if (targ_type==2) { // Quartic * Gauss
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z*0.50; // not quite right (has ~right variance)
    thetall=ArrayXd::Zero(d+1);
    thetall(0)=3; // a
    thetall.tail(d) = scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_QuartGaussCpts;
    likelihood.pgl_fn=&gl_QuartGaussCpts;
    targstr.append("_QG_");  
    cout << "Logistic*Gaussian\n";
  }
  else if (targ_type==3) { //Banana 
    double lam=0.95; // bananacity
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z; //
    x0(1)=lam*(z(0)*z(0)-1)*scales(1)+z(1)*scales(1)/sqrt(1-lam*lam);
    thetall=ArrayXd::Zero(d+1);
    thetall(0)=lam; // lambda
    thetall.tail(d) = scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_BananaTwo;
    likelihood.pgl_fn=&gl_BananaTwo;
    targstr.append("_Ba2_");  
    cout << "BananaTwo\n";
  }
  else if (targ_type==4) {
    //    double lam=0.95; // ~18 mode switches in 10^5 iterations for eps=0.4
    double lam=.9;
    double mu=sqrt(lam), sd=sqrt(1-lam);
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z; //
    x0(0)*=sd; x0(1)*=sd;
    if (StdUnif(gen)<0.5) {
      x0(0)+=mu;  x0(1)+=mu;
    }
    else {
      x0(0)-=mu;  x0(1)-=mu;
    }
    thetall=ArrayXd::Zero(d+1);
    thetall(0)=lam; // lambda
    thetall.tail(d) = scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_BimodalGauss;
    likelihood.pgl_fn=&gl_BimodalGauss;
    targstr.append("_Bi_");  
    cout << "Bimodal Gaussian\n";
  }
  else if (targ_type==5) {
    double lam=0.95; // 
    double sdlo=sqrt(1-lam), sdhi=sqrt(1+lam);
    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = scales*z; //
    if (StdUnif(gen)<0.5) {
      x0(0)*=sdhi;  x0(1)*=sdlo;
    }
    else {
      x0(0)*=sdlo;  x0(1)*=sdhi;
    }
    thetall=ArrayXd::Zero(d+1);
    thetall(0)=lam; // a
    thetall.tail(d) = scales;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_PlusPrism;
    likelihood.pgl_fn=&gl_PlusPrism;
    targstr.append("_Pr_");  
    cout << "Gaussian Prism\n";
  }
  else if ((targ>=12) && (targ<15)) { // Cauchit regression
    int n, d;
    double xsd=1.0, bsd=1.0;
    if (targ==12) {
      n=1000; d=10;
    }
    else if (targ==13) {
      n=1000; d=30;
    }
    else if (targ==14) {
      n=1000; d=100;
    }
    scales=Eigen::ArrayXd::Zero(d)+1.0;

    string xtra="_"+to_string(n)+"C"+to_string(d)+"_";
    targstr.append(xtra);  
    string infnameroot="Cauchit/CauchitData_n"+to_string(n)+"xsd"+to_string((int)(xsd*10))+"_p" +to_string(d)+"bsd"+to_string((int)(bsd*10));
    string betabinname=infnameroot+"_beta.bin";
    string yXbinname=infnameroot+"_yX.bin";

    //    cout << betabinname <<endl;
    //    cout << yXbinname <<endl;    
    
    ifstream readin;
    ArrayXd yX=ArrayXd(n*(d+1)), beta=ArrayXd(d);
    readin.open(betabinname, std::ios::binary);
    readin.read((char*)beta.data(), beta.size()*sizeof(double));
    readin.close();
    readin.open(yXbinname, std::ios::binary);
    readin.read((char*)yX.data(), yX.size()*sizeof(double));
    readin.close();

    cout << beta.matrix().transpose()<<endl;

    x0=beta; thetall=yX;

    prior.theta=ArrayXd::Constant(1,bsd*bsd); 
    prior.pl_fn=&l_GaussIso;
    prior.pgl_fn=&gl_GaussIso;
    likelihood.theta=yX;
    likelihood.pl_fn=&l_Cauchit;
    likelihood.pgl_fn=&gl_Cauchit;
  }
  else if (targ>=15) { // Rasch
    int M=100, N=20;
    double tau=1.0;

    string xtra="_"+to_string(M)+"R"+to_string(N)+"_";
    targstr.append(xtra);  

    scales=Eigen::ArrayXd::Zero(M+N)+1.0;
    scales.tail(N)=ArrayXd::Constant(N,sqrt((double)N/(double)M));// 4precon
    
    string infnameroot="Rasch/RaschData_M"+to_string(M)+"N"+to_string(N)+"tau"+to_string((int)(tau*10));
    string etabetabinname=infnameroot+"_etabeta.bin";
    string ybinname=infnameroot+"_y.bin";

    cout <<"Using data: "<<ybinname<<endl;    
    
    ifstream readin;
    ArrayXd y=ArrayXd(3+M*N), etabeta=ArrayXd(M+N);
    readin.open(etabetabinname, std::ios::binary);
    readin.read((char*)etabeta.data(), etabeta.size()*sizeof(double));
    readin.close();
    readin.open(ybinname, std::ios::binary);
    readin.read((char*)y.data(), y.size()*sizeof(double));
    readin.close();

    //    cout << etabeta.matrix().transpose()<<endl;

    x0=etabeta; // start with true parameter value

    cout <<"tau="<<y(0)<<endl;
    prior.theta=ArrayXd::Constant(1,1/y(0)); // tau=y(0) is inverse variance 
    prior.pl_fn=&l_GaussIso;
    prior.pgl_fn=&gl_GaussIso;
    likelihood.theta=y;
    likelihood.pl_fn=&l_Rasch;
    likelihood.pgl_fn=&gl_Rasch;
  }

  return;
}
