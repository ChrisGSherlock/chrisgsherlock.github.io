#ifndef BINARY_H
#define BINARY_H

double l_Cauchit(const Eigen::ArrayXd &beta, const Eigen::ArrayXd &theta);
Eigen::VectorXd gl_Cauchit(const Eigen::ArrayXd &beta, const Eigen::ArrayXd &theta);

// By default beta is simulated and filled, but if betasd==0 then
// the values are taken from the beta vector
Eigen::ArrayXd sim_Cauchit(const int p, const double betasd, const int n, 
			   const double xsd, std::mt19937 &gen,
			   std::normal_distribution<double> StdNormal,
			   std::uniform_real_distribution<double> StdUnif,
			   Eigen::ArrayXd &beta);

double l_Rasch(const Eigen::ArrayXd &etabeta, const Eigen::ArrayXd &theta);
Eigen::VectorXd gl_Rasch(const Eigen::ArrayXd &etabeta,
			 const Eigen::ArrayXd &theta);

Eigen::ArrayXd sim_Rasch(const int M, const int N, const double tau, 
			 std::mt19937 &gen,
			 std::normal_distribution<double> StdNormal,
			 std::uniform_real_distribution<double> StdUnif,
			 Eigen::ArrayXd &etasbeta);

double l_Rasch_alt(const Eigen::ArrayXd &etabeta, const Eigen::ArrayXd &theta);
Eigen::VectorXd gl_Rasch_alt(const Eigen::ArrayXd &etabeta,
			     const Eigen::ArrayXd &theta);

Eigen::ArrayXd sim_Rasch_alt(const int M, const int N, const double tau, 
			     std::mt19937 &gen,
			     std::normal_distribution<double> StdNormal,
			     std::uniform_real_distribution<double> StdUnif,
			     Eigen::ArrayXd &etasbeta);

#endif
