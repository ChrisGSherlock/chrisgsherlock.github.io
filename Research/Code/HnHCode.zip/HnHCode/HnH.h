void HnH(const int nits, const Eigen::ArrayXd &x0,
	 const double T, const int B, const double lambda, const double kappa,
	 const Eigen::ArrayXd &Sigdiag, const bool jitter,
	 Targd &prior, Targd &likelihood,
	 const std::string outroot="", const std::string outpath="./",
	 const int HopsPerHug=1, const int thin=1, const int prt=0);


