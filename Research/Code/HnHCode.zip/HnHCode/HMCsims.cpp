#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "toy_targets.h"
#include "binary_data.h"
#include "HMC.h"
#include "target_set.h"

using namespace std;
using namespace Eigen;

int CheckInputs(int targ, int nits, int prt, int thin, int precon, double T, int L) {
  int bad=0;

  if ((targ<0) || (targ>15)) {
    cout << "Bad targ: "<<targ<<endl; bad=1;
  }
  if (nits<0) {
    cout << "Bad nits: "<<nits<<endl; bad=1;
  }
  if (prt<0) {
    cout << "Bad prt: "<<prt<<endl; bad=1;
  }
  if (thin<1) {
    cout << "Bad thin: "<<thin<<endl; bad=1;
  }
  if ((precon<0) || (precon>1)) {
    cout << "Bad precon: "<<precon<<endl; bad=1;
  }
  if (L<=0) {
    cout << "Bad L: "<<L<<endl; bad=1;
  }
  if ((targ>11) && (targ<15) && (precon)) {
    cout << "Bad targ+precon combination: "<<targ<<", "<<precon<<endl; bad=1;
  }

  if (!bad) {
    cout << "targ="<<targ<<", nits="<<nits<<", prt="<<prt<<", thin="<<thin<<", precon="<<precon<<", T="<<T<<", L="<<L<<endl;
  }
  
  return bad;
}


// Wrapper for HMC
int main(int argc, const char** pargv)  {
  int targ=0, nits=1, thin=1, prt=1, precon=0, L=1, k=1;
  double T=1.0;
  bool bad=false,Tjitter=false;

  if (argc==1) {
    cout << pargv[0] <<" targ(0) nits(1) prt(1) thin(1) precon(0) T(1) L(1)\n";
    cout << "Defaults in brackets.\n";
    targsprt();
    cout << "nits=#iterations, print every *prt* iterations, thin=thinning factor.\n";
    cout << "precon=0 => no preconditioning, precon=1 => full preconditioning.\n";
    cout << "T<0 => Integrate for Unif[0.8|T|,1.2|T|] each iteration.\n";
    return 0;
  }

  
  if (argc>k) { //
    targ=atoi(pargv[k++]);
  }
  if (argc>k) {
    nits=atoi(pargv[k++]);
  }
  if (argc>k) {
    prt=atoi(pargv[k++]);
  }
  if (argc>k) {
    thin=atoi(pargv[k++]);
  }
  if (argc>k) {
    precon=atoi(pargv[k++]);
  }
  if (argc>k) {
    T=atof(pargv[k++]);
  }
  if (argc>k) {
    L=atoi(pargv[k++]);
  }

  if (T<0) {
    Tjitter=true;
    T=-T;
  }

  bad=CheckInputs(targ,nits,prt,thin,precon,T,L);
  if (bad==1) return 0;
  
  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> StdUnif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  // Create suitable variables for all algorithms
  ArrayXd x0, thetall, thetapri, scales;
  ArrayXd Mdiag;  // diagonal preconditioning for HMC 
  string targstr;
  Targd prior, likelihood;

  // Set up everything to do with the target
  targset(targ, x0,thetapri,thetall,scales, prior,likelihood,targstr,
	  gen, StdNormal, StdUnif);
  cout << targstr << "\n";
  
  if (precon) {  // cannot be set for Cauchit
    Mdiag=1/scales/scales;
  }
  else {
    Mdiag=ArrayXd::Constant(scales.size(),1.0);
  }

  HMC(nits, x0, T, L, Mdiag, Tjitter, prior, likelihood, targstr,"Output/",
      thin, prt);
    
  return 0;
}
