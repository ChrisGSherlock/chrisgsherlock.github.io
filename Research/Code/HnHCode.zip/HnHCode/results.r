##dodo="HMC"
##dodo="NUTS"
dodo="HnH"
##dodo="4paper"


NUTSeps=c(0.1,0.05,0.08,0.12,0.15,0.11,0.09,0.07)
NUTSalpha=c(81.9,99.2,95.1,60.0,24.0,71.7,90.4,97.1)
NUTSess=c(1965,2934,4023,1044,254,1397,3194,18693)
NUTScpu=c(8218,13818,11231,5744,5433,6310,9504,48112)
NUTSlbar=c(11.04,18.88,14.94,7.39,7.05,8.42,13.80,15.04)
NUTSits=c(10000,10000,10000,10000,10000,10000,10000,50000)

if (dodo=="NUTS") {
    par(mfrow=c(3,1))
    plot(NUTSeps,NUTSalpha)
    plot(NUTSlbar,NUTScpu/NUTSits)
    plot(NUTSeps,NUTSess/NUTSlbar/NUTSits*1000)
}

HMCT=c(1,1,1,1,1,1,rep(.5,9))
HMCT=c(HMCT,rep(1.5,6),rep(0.3,4),rep(0.8,10))
HMCL=c(10,15,20,23,25,12, 10,8,12,7,13,14,6,8,5) ##T=1 and .5
HMCL=c(HMCL,17,30,20,19,23,25) ##T=1.5
HMCL=c(HMCL,2,3,4,5) ## T=.3
HMCL=c(HMCL,4,6,8,10,15,11,12,14,16,13) ##T=.8
HMCalpha=c(31.8,72.7,87.6,91.4,93.2,52.2) ##T=1
HMCalpha=c(HMCalpha,89.0,80.7,93.0,72.7,94.1,94.7,60.3,80.3,41.9) ##T=.5
HMCalpha=c(HMCalpha,39.8,86.5,58.3,52.9,71.6,77.8)##T=1.5
HMCalpha=c(HMCalpha,9.3,47.8,72.4,83.4)##T=.3
HMCalpha=c(HMCalpha,0.1,9.0,34.9,58.9,86.6,68.2,73.8,82.9,88.1,79.4) ##T=.8
HMCess=c(3133,10169,14311,15186,15402,6696) ##T=1
HMCess=c(HMCess,6570,6150,7185,4509,7493,7181,3972,5362,2287) ##T=.5
HMCess=c(HMCess,3099,7826,4387,4441,6162,7379)
HMCess=c(HMCess,242,1151,1853,2107)
HMCess=c(HMCess,6,822,3772,7753,14989,10197,10375,13506,14878,11683)##T=.8
HMCcpu=c(7017,10051,13131,14635,15499,7777) ##T=1
HMCcpu=c(HMCcpu,6787,5717,7826,5159,7694,8821,4103,5817,3986) ##T=.5
HMCcpu=c(HMCcpu,10517,18579,12630,12162,14559,15644)
HMCcpu=c(HMCcpu,2121,2726,3330,3881)
HMCcpu=c(HMCcpu,3329,4407,5707,6961,9908,7644,8245,9495,10534,8856) ##T=.8
HMCelp=c(1088,3274,3796,3836,4156,2110) ##T=1
HMCelp=c(HMCelp,3583,3192,3777,2645,3554,3559,2176,2953,1530) ##T=.5
HMCelp=c(HMCelp,1612,4314,2517,2408,3228,3334)
HMCelp=c(HMCelp,290,1590,1787,2408)
HMCelp=c(HMCelp,6,268,1220,2063,3461,2403,2724,3050,3492,3171)
HMCits=rep(20000,35)

if (dodo=="HMC") {
    par(mfrow=c(2,2))
    HMCcol=(HMCT==0.3)*1+(HMCT==0.5)*2+(HMCT==0.8)*3+(HMCT==1)*4+(HMCT==1.5)*5
    plot(HMCL,HMCalpha,col=HMCcol)
    plot(HMCL,HMCcpu/HMCits)
    plot(HMCT/HMCL,HMCess/HMCL/HMCits*1000,col=HMCcol)
    plot(HMCT/HMCL,HMCelp/HMCL/HMCits*1000,col=HMCcol)
}

HnHdel=rep(0.08,34)
HnHdel=c(HnHdel,.08,.08,.08,.12,.1,.1,.1,.12,.12,.12)
HnHdel=c(HnHdel,.08,.06,.05,.06,.08,.06,.04)
HnHdel=c(HnHdel,.08,.07,.06,.05,.05,.0714,.075,.0667,.07,.0636,.05,.05,.0667,.0571,.0727,.0636)
HnHB=rep(4,34)
HnHB=c(HnHB,2,6,8,4,4,6,8,6,8,10,10,10,12,8,12,12,8)
HnHB=c(HnHB,5,6,7,8,10,7,8,9,10,11,16,20,12,14,11,11)
HnHlam=c(0.5,1,2,4,8,16,32,12, 1,2,4,8,0.5,16,32,12,24,48) ## kappa=0.5, 1
HnHlam=c(HnHlam,1,2,.5,4,8,16,32,64) ## kappa =2
HnHlam=c(HnHlam,1,4,16,32,8,2,.5,48) ## kappa =0.25
HnHlam=c(HnHlam,rep(12,33))
HnHmu=c(0.5,0.7071,1,1.414,2,2.828,4,2.45) ## kappa=0.5
HnHmu=c(HnHmu,1,1.414,2,2.828,.7071,4,5.657,3.464,4.90,6.93) ## kappa=1
HnHmu=c(HnHmu,1.414,2,1,2.828,4,5.657,8,11.31) ## kapa=2
HnHmu=c(HnHmu,.5,1,2,2.828,1.414,.7071,.3536,3.46) ## kappa=1/4
HnHmu=c(HnHmu,rep(2.45,33))
HnHahug=74+c(.7,.2,.2,.5,1.0,.6,.7,.4, .6,.4,-.4,.2,-.3,.2,-.2,.2,.4,.8)
HnHahug=c(HnHahug,74+c(.1,.2,.3,.9,.5,.4,.4,.4)) ##kappa=2
HnHahug=c(HnHahug,74+c(-.1,.5,.1,-.1,-.1,.3,1.1,.2)) ##kappa=1/4
HnHahug=c(HnHahug,78.9,70.6,67.4,35.6,55.3,49.3,43.8,27.6,22.6,19.2)
HnHahug=c(HnHahug,64.5,85.0,90.9,86.3,62.3,84.0,95.7)
HnHahug=c(HnHahug,72.8,79.6,86.3,91.6,91.4,77.7,73.1,80.2,75.6,81.3,90.0,89.2,84.0,85.8,72.4,82.2)
HnHahop=c(79.7,78.8,75.6,65.4,47.2,29.5,16.0,35.6) ## kappa=1/2
HnHahop=c(HnHahop,60.6,59.6,55.0,42.1,60.5,26.9,12.7,32.9,18.0,6.5) ## kappa=1
HnHahop=c(HnHahop,31.2,31.0,32.1,29.1,23.5,13.8,3.9,0.1) ## kappa=2
HnHahop=c(HnHahop,88.2,67.9,29.5,16.3,48.0,81.3,88.8,11.0) ## kappa=1/4
HnHahop=c(HnHahop,36+c(.8,.6,.3,.8,.7,-.3,.5,.4,.8,1.1))
HnHahop=c(HnHahop,36+c(.5,.8,.3,.4,.7,.6,.5))
HnHahop=c(HnHahop,36+c(.2,.2,1,.4,.3,-.1,.5,.4,.5,1.2,.6,.2,.6,.1,.4,.2))
HnHess=c(1755,1647,1823,1803,2000,1827,1959,2186) ## kappa=1/2
HnHess=c(HnHess, 1490,1719,1618,2101,1618,1637,1972,2017,1754,1583) ##kappa=1
HnHess=c(HnHess, 1760,1530,1452,1594,1920,1950,1862,2352) ##kappa=2
HnHess=c(HnHess, 1552, 2059, 1830, 1997, 2031, 1859,1661,1954) ##kappa=1/4
HnHess=c(HnHess,646,3633,5586,1780,2060,3772,4002,2379,2142,1720)
HnHess=c(HnHess,6210,5580,6121,4401,5925,7465,2419)
HnHess=c(HnHess,2168,2947,3231,3915,4920,4352,4671,6180,6072,7264,7113,7412,7465,7967,6736,6962)
HnHelp=c(36,57,198,465,685,664,542,800) ##kappa=1/2
HnHelp=c(HnHelp, 154,106,297,645,21,713,498,700,628,304) ## kappa=1
HnHelp=c(HnHelp, 33,58,11,141,313,386,194,36) ## kappa=2
HnHelp=c(HnHelp, 78,442,616,503,579,196,36,355) ## kappa=1/4
HnHelp=c(HnHelp, 690,776,813,630,787,751,699,662,713,558)
HnHelp=c(HnHelp,769,812,928,821,774,800,819)
HnHelp=c(HnHelp,800,704,668,774,755,828,752,782,773,849,778,711,800,747,761,744)
HnHits=rep(20000,67)
HnHcpu=rep(4200,34)
HnHcpu=c(HnHcpu,2999,5441,6631,4181,4151,5407,6216,5176,6198,7117)
HnHcpu=c(HnHcpu,7828,7845,8865,6655,7544,8757,6690)
HnHcpu=c(HnHcpu,4949,5551,6241,6869,8044,6226,6904,6250,7991,8630,11264,13132,8757,10150,7313,7064)

if (dodo=="HnH") {
    fixedHug=1:34
    par(mfrow=c(2,2))
    HnHkappa=round(HnHmu^2/HnHlam,2)
    HnHcolourP=1*(HnHkappa==.25)+2*(HnHkappa==.5)+3*(HnHkappa==1)+4*(HnHkappa==2)
    HnHsymbolP=3*(HnHkappa==.25)+4*(HnHkappa==.5)+8*(HnHkappa==1)+20*(HnHkappa==2)
    alphaHtheory=2*pnorm(-HnHkappa/2)*100
    plot(log(HnHlam[fixedHug]),HnHahop[fixedHug],col=HnHcolourP,pch=HnHsymbolP,xlab=expression("log"~lambda),ylab=expression(alpha["hop"]))
    plot(HnHahop[fixedHug]/alphaHtheory[fixedHug],HnHelp[fixedHug],col=HnHcolourP,pch=HnHsymbolP,xlab=expression(alpha["hop"]~"/"~alpha["theory"]),ylab=expression("ESS ( log"~pi~")"))

    HnHT=HnHB*HnHdel
    HnHcolG=1+(HnHT>.35)+(HnHT>0.45)+(HnHT>0.55)+(HnHT>0.65)+(HnHT>0.75)+(HnHT>0.85)+(HnHT>.95)
    HnHeff=HnHess/HnHits*1000/(HnHB+2)
    HnHeffB=HnHess/HnHcpu
    plot(HnHahug,HnHeff,col=HnHcolG)
    plot(HnHahug,HnHeffB,col=HnHcolG)
}

if (dodo=="4paper") {
    fixedHug=1:34
    par(mfrow=c(1,2))
    HnHkappa=round(HnHmu^2/HnHlam,2)
    HnHcolourP=1*(HnHkappa==.25)+2*(HnHkappa==.5)+3*(HnHkappa==1)+4*(HnHkappa==2)
    HnHsymbolP=3*(HnHkappa==.25)+4*(HnHkappa==.5)+8*(HnHkappa==1)+20*(HnHkappa==2)
    alphaHtheory=2*pnorm(-HnHkappa/2)*100
    plot(log(HnHlam[fixedHug]),HnHahop[fixedHug],col=HnHcolourP,pch=HnHsymbolP,xlab=expression("log"~lambda),ylab=expression(alpha["hop"]))
    vs=200*pnorm(-.5*c(.25,.5,1,2))
    abline(h=vs,col=c(1,2,3,4),lty=4:1)
    abline(v=log(10),col=6,lty=2)
    plot(HnHahop[fixedHug]/alphaHtheory[fixedHug],HnHelp[fixedHug],col=HnHcolourP,pch=HnHsymbolP,xlab=expression(alpha["hop"]~"/"~alpha["theory"]),ylab=expression("ESS ( log"~pi~")"))
    dev.print(pdf,file="CauchitHopExplore.pdf")

}
