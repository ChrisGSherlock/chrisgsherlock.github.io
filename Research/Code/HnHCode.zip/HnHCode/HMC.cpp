#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "/home/sherlocc/Research/Generic_c/Targets/toy_targets.h"

using namespace std;
using namespace Eigen;

// Generic

static void InsertInOutput(Eigen::ArrayXd &x, double lpost, 
			   Eigen::ArrayXXd &Output, int &row) {
  int d=x.size();
  Output.row(row).head(d)=x; // 0 to d-1
  Output.row(row++)(d)=lpost; // d
}



static void PrintInfo(int it, double lpri, double ll, const ArrayXd &x,
		      int nacc)
{
  double di=(double)(it+1);
  cout << "**Iteration="<<it+1<<"\n";
  cout << "lprior="<<lpri<<", ll="<<ll<<", lpost="<<lpri+ll<<"\n";
  cout << "x="<<x.transpose()<<"\n";
  cout << "alpha="<<(double)nacc/(di-1)<<"\n";
}


// Alter x and p as it goes.
static void leapfrogs(const int L, const double eps,
		      ArrayXd &x, ArrayXd &p, const ArrayXd &Mdiag,
		      Targd &prior, Targd &likelihood) {
  ArrayXd g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array(); 
  int l;
  // First half step
  p+=0.5*eps*g;

  // Main set (if L>1)
  for (l=1;l<L;l++) {
    x+=eps*p/Mdiag;
    g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array();
    p+=eps*g;
  }

  // Last bit
  x+=eps*p/Mdiag;
  g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array();
  p+=0.5*eps*g;
}

// HMC

void HMC(const int nits, const ArrayXd &x0,
	 const double T, const int L, const ArrayXd &Mdiag, const bool Tjitter, 
	 Targd &prior, Targd &likelihood, 
	 const string outroot="", const string outpath="./",
	 const int thin=1, const int prt=0) {
  const int d=x0.size(), nout=1+nits/thin;
  int outrow=0; // stored output row
  ArrayXXd Output(nout,d+1);
  ArrayXd xcurr=x0, xprop, p;
  int i, nacc=0;
  bool precon=((Mdiag-ArrayXd::Constant(d,1.0)).matrix().squaredNorm()>1e-5);
  ArrayXd Msqrt=Mdiag.sqrt();
  double eps=T/(double)L;
  string outfnameroot="HMC"+outroot+ "T" +to_string((int)(T*10))+"L"+to_string(L) +"J"+to_string((int)Tjitter) + "A"+to_string((int) precon);
  string outfname=outfnameroot+".txt";
  string outiname=outfnameroot+".info";

  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> Unif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  double llcurr=likelihood.l_fn(xcurr),llprop;
  double lpricurr=prior.l_fn(xcurr),lpriprop;
  double negHcurr, negHprop, lalpha;

  InsertInOutput(xcurr,lpricurr+llcurr,Output, outrow);  

  auto t1 = std::chrono::high_resolution_clock::now();

  for (i=0;i<nits;i++) {
    if (Tjitter) {
      double Tthis=T*(0.8+0.4*Unif(gen));
      eps=Tthis/(double)L;
    }
    if (((i+1) % prt == 0) && (i!=0)) {
      PrintInfo(i,lpricurr,llcurr,xcurr,nacc);
    }

    p=StdNormalAXd(d,gen,StdNormal)*Msqrt; 
    negHcurr=lpricurr+llcurr-0.5*(p*p/Mdiag).sum();

    // This alters xprop and p
    xprop=xcurr;
    //        cout << xprop.t()<<"\n";
    leapfrogs(L,eps, xprop,p, Mdiag, prior, likelihood);
    //        cout << xprop.t()<<"\n";
    llprop=likelihood.l_fn(xprop);
    lpriprop=prior.l_fn(xprop);
    negHprop=lpriprop+llprop-0.5*(p*p/Mdiag).sum();
    
    lalpha=negHprop-negHcurr;

    if (log(Unif(gen))<lalpha) { // accepted
      nacc++;
      xcurr=xprop; llcurr=llprop; lpricurr=lpriprop; 
    }
    
    if ((i+1) % thin == 0) {
      InsertInOutput(xcurr,llcurr+lpricurr,Output,outrow);
    }
  }
  auto t2 = std::chrono::high_resolution_clock::now();

  ofstream outf, outi;
  outf.open(string(outpath+outfname));  
  outf<<Output;
  outf.close();

  double dnits=(double)nits, dnacc=(double)nacc;
  outi.open(string(outpath+outiname));
  outi <<"\n***";
  outi << "nits=" <<nits<<", L="<<L<<", T="<<T<<", Tjitter="<<Tjitter<<", precon="<<precon<<"\n";
  outi << "***\nAcc = " << dnacc/dnits<<"\n";
  outi<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  outi.close();
  cout << "outfiles: "<<outfname<<" and "<<outiname<<"\n";
}

/*
// Wrapper for HMC
int main(int argc, const char** pargv)  {
  int tst=-1, nits=1, L=1, thin=1, prt=10, precon=0, d=10, Twibble=0;
  double T=1.0;
  int k=1;
  
  if (argc>k) { //
    tst=atoi(pargv[k++]);
  }
  if (argc>k) {
    nits=atoi(pargv[k++]);
  }
  if (argc>k) {
    T=atof(pargv[k++]);
  }
  if (argc>k) {
    L=atoi(pargv[k++]);
  }
  if (argc>k) {
    prt=atoi(pargv[k++]);
  }
  if (argc>k) {
    thin=atoi(pargv[k++]);
  }
  if (argc>k) {
    precon=atoi(pargv[k++]);
  }
  if (argc>k) {
    d=atoi(pargv[k++]);
  }
  if (argc>k) {
    Twibble=atoi(pargv[k++]);
  }

  double eps=T/(double)L;
  cout <<"T="<<T<<", L="<<L<<", eps="<<eps<<", prt="<<prt<<", thin="<<thin<<", d="<<d<<"\n";
  arma::arma_rng::set_seed_random();

  if (tst==0) { // Anisotropic Gaussian
    double losd=1, hisd=10;
    arma::dvec sds=arma::linspace<arma::dvec>(losd,hisd,d);
    arma::dvec x0=sds%arma::randn(d);
    vector<double> thetall={losd,hisd};
    arma::dvec Mdiag;
    if (precon) {
      Mdiag=1/(sds%sds);
    }
    else {
      Mdiag=arma::ones(d);
    }
    
    hmc(nits, x0, T, L, Mdiag, Twibble, thetall, thetall, 
	&l_null, &gl_null, &l_GaussLinSD, &gl_GaussLinSD, "linspc",thin, prt);
  }

  if (tst==1) { //light tailed 4th power
    arma::dvec x0=arma::normalise(arma::randn(d));
    vector<double> thetall={4.0,1.0,10.0};
    arma::dvec sds=arma::linspace<arma::dvec>(thetall[1],thetall[2],d);
    x0=x0*exp(log((double)d-1)/thetall[0])%sds; // modal magnitude, random dirn
    cout <<"x0="<< x0.t()<<"\n";

    x0=x0*3.0;
    arma::dvec Mdiag=arma::ones(d);

    hmc(nits, x0, T, L, Mdiag, Twibble, thetall, thetall, 
	&l_null, &gl_null, &l_PowLinSc, &gl_PowLinSc, "pow4",thin, prt);
    
  }
    
  return 0;
}
*/
