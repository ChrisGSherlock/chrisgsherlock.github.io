// NUTS (fixed epsilon) Algorithm 3


// Tested on 10d Gaussian with SDs from 1 to 5 using 10^6 iterations:
//   SDs accurate to < 0.5% for algorithms: 0, 1, 2, 3, 4, 5 (K=0)
//   and all QQ plots look perfect.
//   Using K=2 and 10^5 iterations all accurate to <1%
// Accuracy degrades to perhaps 2% when max_size reduced to 10
//    and QQ some plots look poor in tails. Not surprise as rejection rate~80%

#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "/home/sherlocc/Research/Generic_c/Targets/toy_targets.h"

const double DeltaMax=1000;  

using namespace std;
using namespace Eigen;

struct TreeOut {
  ArrayXd xminu;
  ArrayXd pminu;
  ArrayXd xplus;
  ArrayXd pplus;
  ArrayXd xpp;
  int np;
  bool sp;
};


//*****************************************************
// Class for recording and printing NUTS diagnostics
//*****************************************************
class NUTSd {
  int l, nstored;
  double lbar, l2bar;
public:
  NUTSd();
  void update(int l);
  void printCurr(std::ostream &os);
  void printStats(std::ostream &os);
};

NUTSd::NUTSd() {
  l=0; lbar=0; l2bar=0; nstored=0;
}

void NUTSd::update(int _l) {
  l=_l;

  nstored++;
  double dnrec=1.0/(double)nstored, dl=(double)l;

  lbar=(1-dnrec)*lbar+dnrec*dl;
  l2bar=(1-dnrec)*l2bar+dnrec*dl*dl;
}

void NUTSd::printCurr(std::ostream &os) {
  os <<"*NUTSCurr\n";
  os <<"l="<<l<<std::endl;
}
void NUTSd::printStats(std::ostream &os) {
  os <<"*NUTSStats: nstored="<<nstored<<std::endl;
  os <<"lbar="<<lbar<<" (sd="<<sqrt(l2bar-lbar*lbar+.0001)<<")\n";
}
//*****************************************



//**********************

// Simple utilities
int CheckInputs(int targ, int nits, int prt, int thin, int precon, double par1) {
  int bad=0;

  if (nits<0) {
    cout << "Bad nits: "<<nits<<endl; bad=1;
  }
  if (prt<0) {
    cout << "Bad prt: "<<prt<<endl; bad=1;
  }
  if (thin<1) {
    cout << "Bad thin: "<<thin<<endl; bad=1;
  }
  if ((precon<0) || (precon>1)) {
    cout << "Bad precon: "<<precon<<endl; bad=1;
  }
  if (par1<0) {
    cout << "Bad epsilon: "<<par1<<endl; bad=1;
  }

  if (!bad) {
    cout << "targ="<<targ<<", nits="<<nits<<", prt="<<prt<<", thin="<<thin<<", precon="<<precon<<", par1="<<par1<<endl;
  }
  
  return bad;
}
static int CheckType(const ArrayXi &type) {
  int bad=0;

  if (type(1)<1) {
    cout << "Bad d: "<<type(1)<<endl; bad=1;
  }
  if (type(3)<1) {
    cout << "Bad ecc: "<<type(3)<<endl; bad=1;
  }

  return bad;
}

static void InsertInOutput(Eigen::ArrayXd &x, double lpost, 
			   Eigen::ArrayXXd &Output, int &row) {
  int d=x.size();
  Output.row(row).head(d)=x; // 0 to d-1
  Output.row(row++)(d)=lpost; // d
}


static void PrintInfo(int it, double lpri, double ll, double lalpha,
		      const Eigen::ArrayXd &x, int nacc, int max_xlen=6) {
  double di=(double)(it+1);
  cout << "**Iteration="<<it+1<<endl;
  cout << "lprior="<<lpri<<", ll="<<ll<<", lpost="<<ll+lpri<<", lalphaR="<<lalpha<<endl;
  if (x.size() <= max_xlen) {
    cout << "x="<<x.transpose()<<endl;
  }
  else {
    cout << "x(0:"<<max_xlen-1<<")="<<x.matrix().head(max_xlen).transpose()<<endl;
  }
  cout << "alpha="<<(double)nacc/di<<"\n";
}



//*********************************************

// Hamiltonian
double GetH(ArrayXd &x, ArrayXd &p, const ArrayXd &Mdiag,
	    Targd &prior, Targd &likelihood) {
  double lpri=prior.l_fn(x);
  double ll=likelihood.l_fn(x);
  double lpdens=-0.5*(p*p/Mdiag).sum();
  //  cout <<"tmp H cpts="<<-lpri<<" "<<-ll<<" "<<-lpdens<<endl;
  return -(lpri+ll+lpdens);
}

// Currently nearly twice as many calculations of grad log pi
// as necessary. More than compensate in comparisons by dividing the
// actual CPU time/#calculations by two.
void OneLeapfrog(ArrayXd &x, ArrayXd &p, const ArrayXd &Mdiag, const double eps,
		 Targd &prior, Targd &likelihood, int &lt){
  ArrayXd g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array(); // inefficient TODO
  p+=0.5*eps*g;
  x+=eps*p/Mdiag;
  g=(prior.gl_fn(x)+likelihood.gl_fn(x)).array();
  p+=0.5*eps*g;
  lt++; // track the number of leapfrog steps
}

TreeOut BuildTree(ArrayXd &x, ArrayXd &p, const double logu, const double v,
		  int j, const double eps, const ArrayXd Mdiag, 
		  Targd &prior, Targd &likelihood,
		  mt19937 &gen, uniform_real_distribution<double> Unif, int &lt) {
  ArrayXd xtmp=x, ptmp=p;
  TreeOut bo;
  
  // Base case
  if (j==0) {
    OneLeapfrog(xtmp,ptmp,Mdiag, v*eps, prior, likelihood, lt);
    double Hp=GetH(xtmp,ptmp,Mdiag,prior,likelihood);
    bo.np=(logu <= -Hp);
    bo.sp=(logu < -Hp+DeltaMax);
    
    bo.xminu=xtmp; bo.pminu=ptmp; bo.xplus=xtmp; bo.pplus=ptmp; bo.xpp=xtmp;
    return bo;
  }
  else {
    bo=BuildTree(xtmp,ptmp,logu,v,j-1,eps,Mdiag,prior,likelihood,gen,Unif,lt);
    if (bo.sp==1) {
      TreeOut tmpbo;

      if (v== -1) {
	tmpbo=BuildTree(bo.xminu,bo.pminu,logu,v,j-1,eps,Mdiag,prior,likelihood,gen,Unif,lt);
	bo.xminu=tmpbo.xminu; bo.pminu=tmpbo.pminu;
      }
      else {
	tmpbo=BuildTree(bo.xplus,bo.pplus,logu,v,j-1,eps,Mdiag,prior,likelihood,gen,Unif,lt);
	bo.xplus=tmpbo.xplus; bo.pplus=tmpbo.pplus;
      }
      if (tmpbo.np+bo.np>0) {
	double uu=Unif(gen);
	if (uu<(double) tmpbo.np/((double)(tmpbo.np+bo.np))) {
	  bo.xpp=tmpbo.xpp;
	}
      }

      ArrayXd xdiff=bo.xplus-bo.xminu;
      bo.sp=tmpbo.sp && ((xdiff*bo.pminu).sum()>=0) && ((xdiff*bo.pplus).sum()>=0);
      bo.np+=tmpbo.np;
    }
    return bo;
  }
}



// NUTS
// nits = number of iterations
// x0 = initial vector
// eps = time step
// Mdiag = (inverse preconditioning) vector of masses (diag of matrix)
// prior = parameters, logfn and gradlogfn
// likelihood = parameters, logfn and gradlogfn
// outroot = rootname for output files
// outpath = pathname for output files
// thin = thinning factor (1=no thinning)
// prt = "print every prt iterations"

void NUTS(const int nits, const ArrayXd &x0,
	  const double eps, const ArrayXd &Mdiag,
	  Targd &prior, Targd &likelihood,
	  const string outroot="", const string outpath="./",
	  const int thin=1, const int prt=0) {
  const int d=x0.size(), nout = 1+nits/thin;
  int outrow=0; // stored output row
  ArrayXXd Output(nout,d+1);
  ArrayXd xcurr=x0, xminu, xplus, pminu, pplus;
  int i, nacc=0;
  bool precon=((Mdiag-ArrayXd::Constant(d,1.0)).matrix().squaredNorm()>1e-5);
  ArrayXd Msqrt=Mdiag.sqrt();
  string outfnameroot="NUTS"+outroot+ "eps" + to_string((int) (eps*100)) +"A"+to_string((int) precon);
  string outfname=outfnameroot+".txt";
  string outiname=outfnameroot+".info";
  
  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> Unif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  double llcurr=likelihood.l_fn(xcurr);
  double lpricurr=prior.l_fn(xcurr);
  NUTSd nd;
  TreeOut bo;

  InsertInOutput(xcurr,lpricurr+llcurr,Output, outrow);

  auto t1 = std::chrono::high_resolution_clock::now();
  ArrayXd xprev=xcurr;

  for (i=0;i<nits;i++) {
    ArrayXd pcurr=StdNormalAXd(d,gen,StdNormal)*Msqrt;
    ArrayXd xp;
    double H=GetH(xcurr,pcurr,Mdiag,prior,likelihood);
    double logu=log(Unif(gen))-H;
    int lt=0, j=0, n=1, s=1, np, sp;
    xminu=xcurr; xplus=xcurr; pminu=pcurr; pplus=pcurr;
    
    while (s) {
      if (Unif(gen)<0.5) {
	bo=BuildTree(xminu,pminu,logu,-1,j,eps,Mdiag,prior,likelihood,gen,Unif,lt);
	xminu=bo.xminu; pminu=bo.pminu; xp=bo.xpp; np=bo.np; sp=bo.sp;
      }
      else {
	bo=BuildTree(xplus,pplus,logu,+1,j,eps,Mdiag,prior,likelihood,gen,Unif,lt);
	xplus=bo.xplus; pplus=bo.pplus; xp=bo.xpp; np=bo.np; sp=bo.sp;
      }

      if (np+n>0) {
	if ((sp==1) && (Unif(gen)<(double) np/(double) n)) {
	  xcurr=xp;
	}
      }
      else {
	cout << "n+np<=0\n";
	exit(EXIT_FAILURE);
      }

      n+=np;
      ArrayXd xdiff=xplus-xminu;
      s=sp&&((xdiff*pminu).sum()>=0)&&((xdiff*pplus).sum()>=0);
      j++;
    }

    if ((xprev-xcurr).matrix().norm()>eps/100) {
      xprev=xcurr;
      nacc++;
    }

    nd.update(lt);
    bool toprint=false, tokeep=((i+1)%thin == 0);

    if ((i>0) || (prt>0)) {
      toprint=((i+1) % prt == 0); // account for iteration index starting at 0
    }

    if (toprint || tokeep) {
      llcurr=likelihood.l_fn(xcurr);
      lpricurr=prior.l_fn(xcurr);
    }
    
    
    if (toprint){
      PrintInfo(i,lpricurr,llcurr,0,xcurr,nacc);
      nd.printCurr(cout);
      nd.printStats(cout);
    }
    if (tokeep) { 
      InsertInOutput(xcurr,llcurr+lpricurr,Output,outrow);
    }
  }

  auto t2 = std::chrono::high_resolution_clock::now();

  ofstream outf, outi;
  outf.open(string(outpath+outfname));  
  outf<<Output;
  outf.close();

  double dnits=(double)nits, dnacc=(double)nacc;
  outi.open(string(outpath+outiname));
  outi <<"\n***";
  outi << "nits=" <<nits<<", eps="<<eps<<", precon="<<precon<<"\n";
  outi << "***\nAcc = " << dnacc/dnits<<"\n";
  outi<< "Time: "<<std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() <<"\n";
  nd.printStats(outi);
  outi.close();
  cout << "outfiles: "<<outfname<<" and "<<outiname<<"\n";
}

/*
int main(int argc, const char** pargv)  {
  int targ=0, nits=1, thin=1, prt=1, precon=0, i=1, bad;
  double par1=0.0; // epsilon

  if (argc==1) {
    cout << pargv[0] <<" targ(0) nits(1) prt(1) thin(1) precon(0) eps(0.0)\n";
    cout << "Defaults in brackets.\n";
    cout << "Targs:\n0=10d Gaussian with SDs 1-5;\n1=50d Gaussian with diag Hess 1-10.\nGeneral Ddddseee where D=distribution (0=Gaussian, 1=logistic), d=dimension, s=scale spacing (0=SD, 1=Var, 2=invSD, 3=Hess, +4 if jittered, 8=RadfordNeal-like)";
    cout << "nits=#iterations, print every *prt* iterations, thin=thinning factor.\n";
    cout << "precon=0 => no preconditioning, precon=1 => full preconditioning.\n";
    return 0;
  }
  
  if (argc>1) { 
    targ=atoi(pargv[i++]);
  }
  if (argc>2) {
    nits=atoi(pargv[i++]);
  }
  if (argc>3) {
    prt=atoi(pargv[i++]);
  }
  if (argc>4) {
    thin=atoi(pargv[i++]);
  }
  if (argc>5) {
    precon=atoi(pargv[i++]);
  }
  if (argc>6) {
    par1=atof(pargv[i++]); // epsilon
  }

  bad=CheckInputs(targ,nits,prt,thin,precon,par1);
  if (bad==1) return 0;
  
  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> StdUnif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  // Create suitable variables for all algorithms
  ArrayXd x0, thetall, thetapri, tmp, Scales, Sigma;
  ArrayXi targ_type(4);
  ArrayXd Mdiag;  // diagonal preconditioning for HMC 
  string targstr;
  Targd prior, likelihood;
  double max_ecc;
  int d;
  
  if (targ==0) { // 10d Gauss with SDs linear from 1 to 5
    targ_type<<0,10,0,5;
    cout << "10d Gaussian with SD linear from 1 to 5\n";
  }
  else if (targ==1) { // 50d Gaussian with diag Hess from 1 to 100.
    targ_type<<0,50,2,10;
    cout << "50d Gaussian with diag Hess linear from 1 to 100\n";
  }
  else {
    // Ddddseee   D=distribution, d=dimension, s=scale spacing, e=eccentricity
    
    targ_type(0) =  targ / 10000000;
    targ_type(1) = (targ - targ_type(0)*10000000)/10000;
    targ_type(2) = (targ - targ_type(0)*10000000 - targ_type(1)*10000)/1000;
    targ_type(3) =  targ - targ_type(0)*10000000 - targ_type(1)*10000 - targ_type(2)*1000;
  }

  bad=CheckType(targ_type);
  if (bad==1) return 0;
  
  d = targ_type(1);
  max_ecc = targ_type(3) * 1.0;
  targstr = "D" + to_string(d) + "_E"+to_string(targ_type(3));

  if ((targ_type(2)>=0) && (targ_type(2)<=3)) {
    if(targ_type(2) == 0){
      targstr.append("_SDlinspc");  
      tmp = Eigen::ArrayXd::LinSpaced(d,1.0,max_ecc);
      Sigma = tmp*tmp;
      
    } else if(targ_type(2) == 1){
      targstr.append("_VARlinspc");
      tmp = Eigen::ArrayXd::LinSpaced(d,1.0,max_ecc*max_ecc);
      Sigma = tmp;
      
    } else if(targ_type(2) == 2){
      targstr.append("_Hlinspc");
      tmp = Eigen::ArrayXd::LinSpaced(d,1.0,max_ecc*max_ecc);
      Sigma = (max_ecc*max_ecc)/tmp;
      
    } else if(targ_type(2) == 3){
      targstr.append("_invSDlinspc");
      tmp = Eigen::ArrayXd::LinSpaced(d,1.0,max_ecc);
      Sigma = (max_ecc*max_ecc)/tmp/tmp;
    }
    
    std::sort(Sigma.data(),Sigma.data()+Sigma.size());
    Scales=Sigma.sqrt();
      
  } else if(targ_type(2)>=4 && targ_type(2)<=7){
    std::mt19937 fixedgen(1234567);
    double ddm1=(double)d-1;
    tmp = Eigen::ArrayXd::LinSpaced(d,0.0,ddm1); // 0 to d-1
    for(int cpt=1;cpt<d-1; cpt++){
      tmp(cpt) += StdUnif(fixedgen)-0.5;
    }
    tmp=tmp/ddm1; // now from 0 to 1 with the right jitter
      
    if(targ_type(2) == 4){
      targstr.append("_SDunif");   
      Scales=tmp*(max_ecc-1)+1;
      Sigma=Scales*Scales;
	
    } else if(targ_type(2) == 5){
      targstr.append("_VARunif");
      Sigma=tmp*(max_ecc*max_ecc-1)+1;
      Scales=Sigma.sqrt();
	
    } else if(targ_type(2) == 6){
      targstr.append("_Hunif");
      double oneoxi2=1/max_ecc/max_ecc;
      tmp=oneoxi2+tmp*(1-oneoxi2); // Hess
      Sigma=1/tmp;
      Scales=Sigma.sqrt();

    } else if(targ_type(2) == 7){
      targstr.append("_invSDunif");
      double oneoxi=1/max_ecc;
      tmp=oneoxi+tmp*(1-oneoxi);
      Scales=1/tmp;
      Sigma=Scales*Scales;
    }
    
    std::sort(Scales.data(),Scales.data()+Scales.size());
    std::sort(Sigma.data(),Sigma.data()+Sigma.size());
  }
  //  cout <<"Scales\n";
  //  cout <<Scales.matrix().transpose()<<endl;
  if(targ_type(0) == 0){
            
    targstr.insert(0,"Gauss_");

    ArrayXd z=StdNormalAXd(d,gen,StdNormal);
    x0 = Scales*z;
    thetall=ArrayXd::Zero(2*d);
    thetall.tail(d) = Sigma;
    prior.theta=ArrayXd::Zero(1); // any value as is irrelevant
    prior.pl_fn=&l_null;
    prior.pgl_fn=&gl_null;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_GaussDiag;
    likelihood.pgl_fn=&gl_GaussDiag;
  } else if(targ_type(0) == 1){
    targstr.insert(0,"Logis_");
    ArrayXd z=StdLogisticAXd(d,gen,StdUnif);
    x0 = Scales*z;
    thetall=ArrayXd::Zero(2*d);
    thetall.tail(d) = Scales;
    
    prior.theta=ArrayXd::Zero(1); // any value as is irrelevant
    prior.pl_fn=&l_null;
    prior.pgl_fn=&gl_null;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_LogisticCpts;
    likelihood.pgl_fn=&gl_LogisticCpts;

  } else if(targ_type(0) == 2){ 
    double omega=3.0; // Skewness parameter hardwired to 3
    targstr.insert(0,"SkewN_");  // Szymon: please check 3 is neither to big nor too small
    ArrayXd z=StdSkewNormalAXd(d,omega,gen,StdNormal); 
    x0 = Scales*z;
    thetall=ArrayXd::Zero(d+1);
    thetall.tail(1) = Scales;
    thetall(0)=omega;

    prior.theta=ArrayXd::Zero(1); // any value as is irrelevant
    prior.pl_fn=&l_null;
    prior.pgl_fn=&gl_null;
    likelihood.theta=thetall;
    likelihood.pl_fn=&l_SkewNormalCpts;
    likelihood.pgl_fn=&gl_SkewNormalCpts;

  }	
   cout << targstr << "\n";

  if (precon) {
    Mdiag=1/Sigma;
  }
  else {
    Mdiag=ArrayXd::Constant(d,1.0);
  }
  
  NUTS(nits, x0, par1, Mdiag, prior, likelihood, targstr,"Output/", thin, prt);

  return 0;
}
*/
