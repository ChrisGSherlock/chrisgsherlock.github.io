void NUTS(const int nits, const Eigen::ArrayXd &x0,
	  const double eps, const Eigen::ArrayXd &Mdiag,
	  Targd &prior, Targd &likelihood,
	  const std::string outroot="", const std::string outpath="./",
	  const int thin=1, const int prt=0);


int CheckInputs(int targ, int nits, int prt, int thin, int precon, double par1);
