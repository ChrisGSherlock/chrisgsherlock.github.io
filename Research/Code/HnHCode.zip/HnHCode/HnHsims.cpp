#include <iostream>
#include <fstream>
#include <Eigen/Core>
#include <Eigen/Eigenvalues> // needed for preconditioning
#include <chrono>
#include <random>
#include "toy_targets.h"
#include "binary_data.h"
#include "HnH.h"
#include "target_set.h"

using namespace std;
using namespace Eigen;

int CheckInputs(int targ, int nits, int prt, int thin, int precon, double T, int B, double lambda, double kappa) {
  int bad=0;

  if ((targ<0) || (targ>15)) {
    cout << "Bad targ: "<<targ<<endl; bad=1;
  }
  if (nits<0) {
    cout << "Bad nits: "<<nits<<endl; bad=1;
  }
  if (prt<0) {
    cout << "Bad prt: "<<prt<<endl; bad=1;
  }
  if (thin<1) {
    cout << "Bad thin: "<<thin<<endl; bad=1;
  }
  if ((precon<0) || (precon>1)) {
    cout << "Bad precon: "<<precon<<endl; bad=1;
  }
  if (T==0) {
    cout << "Bad T: "<<T<<endl; bad=1;
  }
  if (B<=0) {
    cout << "Bad B: "<<B<<endl; bad=1;
  }
  if (lambda<=0) {
    cout << "Bad lambda: "<<lambda<<endl; bad=1;
  }
  if (kappa<0) {
    cout << "Bad kappa: "<<kappa<<endl; bad=1;
  }
  if ((targ>11) && (targ<15) && (precon)) {
    cout << "Bad targ+precon combination: "<<targ<<", "<<precon<<endl; bad=1;
  }

  if (!bad) {
    cout << "targ="<<targ<<", nits="<<nits<<", prt="<<prt<<", thin="<<thin<<", precon="<<precon<<", T="<<T<<", B="<<B<<", lambda="<<lambda<<", kappa="<<kappa<<endl;
  }
  
  return bad;
}


// Wrapper for HMC
int main(int argc, const char** pargv)  {
  int targ=0, nits=1, thin=1, prt=1, precon=0, B=1, k=1;
  int HpH=1; // HopsPerHug: -1 = no hug.
  double lambda=1.0, T=0.0, kappa=0.0;
  bool bad=false,jitter=false;

  if (argc==1) {
    cout << pargv[0] <<" targ(0) nits(1) prt(1) thin(1) precon(0) T(0) B(1) lambda(1) kappa(0) HopsPerHug(1)\n";
    cout << "Defaults in brackets.\n";
    targsprt();
    cout << "nits=#iterations, print every *prt* iterations, thin=thinning factor.\n";
    cout << "precon=0 => no preconditioning, precon=1 => full preconditioning.\n";
    cout << "T<0 => Set T = Unif[0.8|T|,1.2|T|] each iteration.\n";
    return 0;
  }

  
  if (argc>k) { //
    targ=atoi(pargv[k++]);
  }
  if (argc>k) {
    nits=atoi(pargv[k++]);
  }
  if (argc>k) {
    prt=atoi(pargv[k++]);
  }
  if (argc>k) {
    thin=atoi(pargv[k++]);
  }
  if (argc>k) {
    precon=atoi(pargv[k++]);
  }
  if (argc>k) {
    T=atof(pargv[k++]);
  }
  if (argc>k) {
    B=atoi(pargv[k++]);
  }
  if (argc>k) {
    lambda=atof(pargv[k++]);
  }
  if (argc>k) {
    kappa=atof(pargv[k++]);
  }
  if (argc>k) {
    HpH=atof(pargv[k++]); // hops per hug
  }

  if (T<0) {
    jitter=true; // jitter hug time
    T=-T;
  }

  bad=CheckInputs(targ,nits,prt,thin,precon,T,B,lambda,kappa);
  if (bad==1) return 0;
  
  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> StdUnif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  // Create suitable variables for all algorithms
  ArrayXd x0, thetall, thetapri, scales;
  ArrayXd Sigdiag;  // diagonal preconditioning for HnH
  string targstr;
  Targd prior, likelihood;

  // Set up everything to do with the target
  targset(targ, x0,thetapri,thetall,scales, prior,likelihood,targstr,
	  gen, StdNormal, StdUnif);
  cout << targstr << "\n";

  if (precon) { // cannot be set for cauchit
    Sigdiag=scales*scales;
  }
  else {
    Sigdiag=ArrayXd::Constant(scales.size(),1.0);
  }

  HnH(nits, x0, T, B, lambda, kappa, Sigdiag, jitter, prior, likelihood,
      targstr,"Output/", HpH, thin, prt);
    
  return 0;
}
