#Code for Hug and Hop, and comparison against HMC and NUTS.

This is the code that was used for the 30d and 100d Cauchit comparison and the Rasch comparison. Essentially the same code was also used for the "difficult" bimodal comparison.

The other runs were performed by Matt Ludkin using code which is written in a much more generic fashion - please contact him for details.

You will need eigen installed on your machine.

## Compilation
./compHnH
./compHMC
./compNUTS

## Help
./HnH
./HMC
./NUTS

## Output will appear in the Output directory

## Run the 30-d Cauchit comparison
Use 1000 iterations for brevity, printing output to screen every 100.
Use optimal parameter settings.
Use jittering on T (so writing -0.7 rather than 0.7).
./HnH 13 1000 100 1 0 -0.7 6 12 0.5
./HMC 13 1000 100 1 0 -0.5 5
./NUTS 13 1000 100 1 0 0.11

## Run the 100-d Cauchit comparison
./HnH 14 1000 100 1 0 -0.8 11 12 0.5
./HMC 14 1000 100 1 0 -0.8 14
./NUTS 14 1000 100 1 0 0.08

## Run the Rasch comparison (with pre-conditioning as in the paper)
./HnH 15 1000 100 1 1 -1.2 5 15 0.25
./HMC 15 1000 100 1 1 -1.0 5
./NUTS 15 1000 100 1 1 0.25

## Data
The data files and the files to simulate the data are in the Cauchit and Rasch directories.


