#include <iostream>
#include <Eigen/Core>
#include <random>
#include "toy_targets.h"
#include "binary_data.h"

using namespace std;
using namespace Eigen;

const double _PI = 3.14159265358979323846;

// To test on its own, remove the comments around main() then
// g++ -I /usr/include/eigen3 binary_data.cpp
// When linking with another main file: #include "binary_data.h"

//------------
//**********Cauchit regression****************

// log-likelihood
double l_Cauchit(const ArrayXd &beta, const ArrayXd &theta) {
  int d=beta.size(), n=theta.size()/(d+1), i, j;
  ArrayXd ys=theta.head(n);
  double ll=0;
  // NB: X_{i,j}=theta(i+(j+1)*n) is the design matrix
  
  for (i=0;i<n;i++) {
    double etai=0;
    for (j=0;j<d;j++) {
      etai+=theta(i+(j+1)*n)*beta(j);
    }
    ll+=log(0.5+atan(ys(i)*etai)/_PI);
  }
  return ll;
}

// gradient of log likelihood
VectorXd gl_Cauchit(const ArrayXd &beta, const ArrayXd &theta) {
  int d=beta.size(), n=theta.size()/(d+1), i, j;
  ArrayXd ys=theta.head(n);
  ArrayXd g=ArrayXd::Zero(d);
  // NB: X_{i,j}=theta(i+(j+1)*n) is the design matrix
  
  for (i=0;i<n;i++) {
    double etai=0;
    for (j=0;j<d;j++) {
      etai+=theta(i+(j+1)*n)*beta(j);
    }
    double tmp1=_PI/2.0+atan(ys(i)*etai);
    double tmp2=1+etai*etai;
    for (j=0;j<d;j++) {
      g(j)+=ys(i)*theta(i+(j+1)*n)/tmp1/tmp2;
    }
  }
  return g.matrix();
}

ArrayXd sim_Cauchit(const int p, const double betasd, const int n, 
		    const double xsd, std::mt19937 &gen,
		    std::normal_distribution<double> StdNormal,
		    std::uniform_real_distribution<double> StdUnif,
		    ArrayXd &betas) {
  int i, j;
  ArrayXd theta=ArrayXd(n*(p+1));
    
  for (j=0;j<p;j++) {
    // If betasd==0 then we use the values in the vector
    // ... so the caller must ensure they are set!
    if (betasd>0) {
      betas(j)=StdNormal(gen)*betasd;
    }
    else if (betasd<0) {
      betas(j)=StdUnif(gen)>0.5?1:-1;
    }
  }
  for (i=0;i<n;i++) {
    double etai=0,prob;
    for (j=0;j<p;j++) {
      int index=i+(j+1)*n;
      if (xsd>0) {
	theta(index)=StdNormal(gen)*xsd;
      }
      else {
	theta(index)=StdUnif(gen)>0.5?1:-1;
      }
      etai+=theta(index)*betas(j); //X_{i,j}beta_j
    }
    prob=atan(etai)/_PI+0.5;
    theta(i)=StdUnif(gen)<prob?1:-1; // Y_i
  }

  return theta;
}

//**********Rasch****************

//The AAPS paper, unintuitively, had i for the test and j for the person;
// I've changed this. Now:
// beta_j is the test difficulty and eta_i is the person ability;
// i=1,..,M and j=1,...,N.
// So now there is one column for each test.
//
// State vector is (eta_1,...,eta_M,beta_1,beta_2,...,beta_N)
// "alt" version has beta_1=0 for identifiability
// as beta_1=0 for identifiability
// Data are (tau,M,N,y_{1,1},...,y_{M,1},...,...,y_{1,N},...,y_{M,N})

// log-likelihood
double l_Rasch(const ArrayXd &x, const ArrayXd &theta) {
  int d=x.size(), M=theta(1), N=theta(2), i, j;
  if (d != N+M) {
    cout << "x length=" << d <<" yet N+M="<<N+M<<endl;
    exit(EXIT_FAILURE);
  }
  ArrayXd ys=theta.tail(N*M);
  ArrayXd etas=x.head(M), betas=x.tail(N);
  double ll=0, etai, betaj;
  
  for (i=0;i<M;i++) {
    etai=etas(i);
    for (j=0;j<N;j++) {
      betaj=betas(j);
      double yij=ys(i+j*M);
      ll+=logPhi(yij*(etai-betaj));
    }
  }
  //  ll-= 0.5*(x*x).sum()*theta(0); // this is now in the prior
  return ll;
}
double l_Rasch_alt(const ArrayXd &x, const ArrayXd &theta) {
  int d=x.size(), M=theta(1), N=theta(2), i, j;
  if (d != N+M-1) {
    cout << "x length=" << d <<" yet N+M="<<N+M<<endl;
    exit(EXIT_FAILURE);
  }
  ArrayXd ys=theta.tail(N*M);
  ArrayXd etas=x.head(M), betas=x.tail(N-1);
  double ll=0, etai, betaj;
  
  for (i=0;i<M;i++) {
    etai=etas(i);
    for (j=0;j<N;j++) {
      betaj=(j==0)?0:betas(j-1);
      double yij=ys(i+j*M);
      ll+=logPhi(yij*(etai-betaj));
    }
  }
  //  ll-= 0.5*(x*x).sum()*theta(0); // this is now in the prior
  return ll;
}

// gradient of log likelihood
VectorXd gl_Rasch(const ArrayXd &x, const ArrayXd &theta) {
  int d=x.size(), M=theta(1), N=theta(2), i, j;
  double etai, betaj;
  if (d != N+M) {
    cout << "x length=" << d <<" yet N+M="<<N+M<<endl;
    exit(EXIT_FAILURE);
  }
  ArrayXd ys=theta.tail(N*M);
  ArrayXd etas=x.head(M), betas=x.tail(N);
  
  ArrayXd g=ArrayXd::Zero(M+N);// was -theta(0)*x; // gradient of prior
  
  for (i=0;i<M;i++) {
    etai=etas(i);
    for (j=0;j<N;j++) {
      betaj=betas(j);
      double yij=ys(i+j*M);
      double tmp=phiOPhi(yij*(etai-betaj));
      g(i)+= yij*tmp; // d/d eta_i
      g(M+j)-= yij*tmp; // d/d beta_j
    }
  }

  return g.matrix();
}
VectorXd gl_Rasch_alt(const ArrayXd &x, const ArrayXd &theta) {
  int d=x.size(), M=theta(1), N=theta(2), i, j;
  double etai, betaj;
  if (d != N+M-1) {
    cout << "x length=" << d <<" yet N+M="<<N+M<<endl;
    exit(EXIT_FAILURE);
  }
  ArrayXd ys=theta.tail(N*M);
  ArrayXd etas=x.head(M), betas=x.tail(N-1);
  
  ArrayXd g=ArrayXd::Zero(M+N-1);// was -theta(0)*x; // gradient of prior
  
  for (i=0;i<M;i++) {
    etai=etas(i);
    for (j=0;j<N;j++) {
      betaj=(j==0)?0:betas(j-1);
      double yij=ys(i+j*M);
      double tmp=phiOPhi(yij*(etai-betaj));
      g(i)+= yij*tmp; // d/d eta_i
      if (j>0) {
	g(M+j-1)-= yij*tmp; // d/d beta_j
      }
    }
  }

  return g.matrix();
}
// "theta"=(tau,M,N,y)
ArrayXd sim_Rasch(const int M, const int N, const double tau, std::mt19937 &gen,
		  std::normal_distribution<double> StdNormal,
		  std::uniform_real_distribution<double> StdUnif,
		  ArrayXd &etasbetas) {
  int i, j;
  ArrayXd theta=ArrayXd(3+M*N);
  double sd=1/sqrt(tau), etai, betaj;
  theta(0)=tau; theta(1)=M; theta(2)=N;
  
  for (i=0;i<M+N;i++) {
    etasbetas(i)=sd*StdNormal(gen);
  }

  for (i=0;i<M;i++) {
    etai=etasbetas(i);
    for (j=0;j<N;j++) {
      betaj=etasbetas(j+M);
      double logp=logPhi(etai-betaj);
      if (log(StdUnif(gen))<logp) {
	theta(i+M*j+3)=1;
      }
      else {
	theta(i+M*j+3)=-1;
      }
    }
  }

  return theta;
}
ArrayXd sim_Rasch_alt(const int M, const int N, const double tau,
		      std::mt19937 &gen,
		      std::normal_distribution<double> StdNormal,
		      std::uniform_real_distribution<double> StdUnif,
		      ArrayXd &etasbetas) {
  int i, j;
  ArrayXd theta=ArrayXd(3+M*N);
  double sd=1/sqrt(tau), etai, betaj;
  theta(0)=tau; theta(1)=M; theta(2)=N;
  
  for (i=0;i<M+N-1;i++) {
    etasbetas(i)=sd*StdNormal(gen);
  }

  for (i=0;i<M;i++) {
    etai=etasbetas(i);
    for (j=0;j<N;j++) {
      betaj=(j==0)?0:etasbetas(j-1+M);
      double logp=logPhi(etai-betaj);
      if (log(StdUnif(gen))<logp) {
	theta(i+M*j+3)=1;
      }
      else {
	theta(i+M*j+3)=-1;
      }
    }
  }

  return theta;
}

/*
// Test 
int main() {
  int p=4, n=20, M=20, N=4;
  double betasd=1, xsd=2, tau=1;
  double l;
  ArrayXd gl;

  std::random_device rd;  //Will use to obtain seed for random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_real_distribution<> StdUnif(0.0, 1.0);
  std::normal_distribution<double> StdNormal(0.0, 1.0);

  // Cauchit regression
  cout<<"Cauchit regression with beta="<<endl;
  ArrayXd betas=ArrayXd(p);
  ArrayXd thcau=sim_Cauchit(p, betasd, n, xsd, gen, StdNormal, StdUnif, betas);

  cout<<betas.matrix().transpose()<<endl;
  cout<<"y="<<thcau.head(n).matrix().transpose()<<endl;
  cout<<"X="<<thcau.tail(n*p).matrix().transpose()<<endl;

  l=l_Cauchit(betas, thcau);
  gl=gl_Cauchit(betas, thcau);
  cout << "log-like=" << l <<endl<<"g="<<endl<<gl.transpose()<<endl;
  gl=glp_from_lp(betas, thcau, &l_Cauchit,0.001);
  cout << "g num="<< endl<<gl.transpose()<<endl;

  // Rasch
  cout<<"Rasch with etasbetas="<<endl;
  ArrayXd etasbetas=ArrayXd(M+N);
  ArrayXd thrasch=sim_Rasch(M, N, tau, gen, StdNormal, StdUnif, etasbetas);
  ArrayXd etasbetas_alt=ArrayXd(M+N-1);
  ArrayXd thrasch_alt=sim_Rasch_alt(M, N, tau, gen, StdNormal, StdUnif,
				    etasbetas_alt);
  
  cout<<etasbetas.matrix().transpose()<<endl;
  cout<<"y="<<thrasch.tail(N*M).matrix().transpose()<<endl;

  l=l_Rasch(etasbetas, thrasch);
  gl=gl_Rasch(etasbetas, thrasch);
  cout << "log-like=" << l <<endl<<"g="<<endl<<gl.transpose()<<endl;
  gl=glp_from_lp(etasbetas, thrasch, &l_Rasch,0.0001);
  cout << "g num="<<endl<<gl.transpose()<<endl;
  l=l_Rasch_alt(etasbetas_alt, thrasch_alt);
  gl=gl_Rasch_alt(etasbetas_alt, thrasch_alt);
  cout << "log-like=" << l <<endl<<"g="<<endl<<gl.transpose()<<endl;
  gl=glp_from_lp(etasbetas_alt, thrasch_alt, &l_Rasch_alt,0.0001);
  cout << "g num="<<endl<<gl.transpose()<<endl;

  
  return 0;
}

*/
